<?php
/**
 * Plugin Name: Tiles Calculator
 * Plugin URI: 
 * Description: Calculate tiles required.
 * Version: 1.0
 * Author: Pratap
 * Author URI: 
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Text Domain: ctcal
 * Domain Path: /languages/
 */
/*
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
    exit;
}

/*
 * Define variables
 */
global $wpdb;
define('CTC_FILE', __FILE__);
define('CTC_DIR', plugin_dir_path(CTC_FILE));
define('CTC_URL', plugins_url('/', CTC_FILE));
define('CTC', 'ctcal');

/**
 * Main Plugin CHG class.
 */
class CTC_Class {

    /**
     * CHG constructor.
     */
    public function __construct() {
        $this->CTC_hooks();
        $this->CTC_include_files();
    }

    /**
     * Initialize hooks
     */
    public function CTC_hooks() {
        add_action('plugins_loaded', array($this, 'CTC_load_language_files'));
        add_action('admin_enqueue_scripts', array($this, 'CTC_admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'CTC_user_scripts'));
    }

    /**
     * Include required files
     */
    public function CTC_include_files() {
        include_once( CTC_DIR . 'includes/ctc-calculator.php' );
    }

    /**
     * Loads plugin textdomain
     */
    public function CTC_load_language_files() {
        load_plugin_textdomain(CTC, false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /**
     *
     * Enqueue admin panel required css/js
     */
    public function CTC_admin_scripts() {

        wp_register_style('ctc-admin-style', CTC_URL . 'assets/css/admin-style.css');
		wp_enqueue_style('ctc-admin-style');

        wp_register_script('ctc-admin-script', CTC_URL . 'assets/js/admin-script.js', array('jquery'), false, true);
        wp_enqueue_script('ctc-admin-script');
		
    }

	/**
     *
     * Enqueue user panel required css/js
     */
    public function CTC_user_scripts() {

        wp_register_style('ctc-user-style', CTC_URL . 'assets/css/user-style.css');
		wp_enqueue_style('ctc-user-style');

		wp_register_script('ctc-user-script', CTC_URL . 'assets/js/user-script.js', array('jquery'), false, true);
        wp_enqueue_script('ctc-user-script');
		
		wp_localize_script( 'ctc-user-script', 'my_ajaxurl', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
		wp_enqueue_style( 'font-awesome-free', '//use.fontawesome.com/releases/v5.2.0/css/all.css' );
    }
}

/*
* Starts our plugin class, easy!
*/
new CTC_Class();