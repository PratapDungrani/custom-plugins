<?php
/**
 * Calculator shortcode
 *
 */
function ctc_tiles_calculator() {
	ob_start();
	?>
	<style>
	.calc-container, .calc-result, .tiles-img {
		width:100%;
		padding: 25px;
		border: 1px solid #808080;
		font-family: sans-serif;
	}
	.input-title, .result-title, .tips-title {
		width: 100%;
		padding: 10px 20px;
		margin: 0 auto;
		font-size: 22px;
		font-weight: 600;
		letter-spacing: 1px;
		line-height: 24px;
		background-color: #000;
		color: #EFF3F8;
	}
	.calc-input {
		width:80%;
		margin: 0 auto;
	}
	.calc-input label {
		font-size: 20px;
		font-weight: 700;
		letter-spacing: 1px;
	}
	.tiles-length, .tiles-width {
		height:50px;
		border: 3px solid #ddd;
		border-radius: 7px;
	}
	.calc-input input[type="number"] {
		background: transparent;
		width: 100%;
		height: 100%;
		border: none;
		outline: none;
		font-size: 24px;
		line-height:24px;
		letter-spacing: 1.5px;
		font-weight: 700;
		text-shadow: 0 1px 0 #ccc,0 2px 0 #fff,0 3px 0 #bbb,0 4px 0 #b9b9b9,0 5px 0 #aaa;
	}
	input[type="number"]::placeholder {  
		text-align: right;
		padding-right: 10px;
		text-shadow: none;
		letter-spacing: 0;
		font-size: 22px;
		font-weight: 500;
		font-family: cursive !important;
	}
	select:focus { outline: none; }
	select {
		-webkit-appearance: none;
		font-size: 18px;
		line-height: 18px;
		font-weight: 600;
		cursor: pointer;
		background: transparent;
		width: 100%;
	}
	.select {
		position: relative;
		border: 3px solid #ddd;
		border-radius: 7px;
	}
	.fa-arrow-alt-circle-down {
		position: absolute;
		right: 20px;
		top: calc(50% - 0.5em);
		right: 5%;
		font-size:24px;
		color: #ccc;
	}
	.myButton {
		margin-top: 25px;
		box-shadow: 0px 10px 14px -7px #3e7327;
		background:linear-gradient(to bottom, #77b55a 5%, #72b352 100%);
		background-color:#77b55a;
		border-radius:4px;
		border:1px solid #4b8f29;
		display:inline-block;
		cursor:pointer;
		color:#ffffff;
		font-family:Arial;
		font-size:16px;
		font-weight:bold;
		padding:10px 30px;
		text-decoration:none;
		text-shadow:0px 1px 0px #5b8a3c;
	}
	.myButton:hover {
		background:linear-gradient(to bottom, #72b352 5%, #3e7327 100%);
		background-color: #3e7327;
	}
	.myButton:active {
		position:relative;
		top:1px;
	}
	.calc-result, .tiles-img {
		margin-top: 50px;
	}
	.total-area {
		padding-top: 50px;
		display: flex;
		width: 80%;
		margin: 0 auto;
	}
	.area-title, .left-tiles {
		width: 200px;
		height: 100px;
		border: 1px solid #ccc;
		font-size: 18px;
		font-weight: 600;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.square {
		width: 100px;
		height: 100px;
		margin-left:50px;
		border-radius: 2%;
		box-shadow: 0 0 0 5px #ccc;
		transition: .5s;
		position: relative;
		cursor: pointer;
		text-align: center;
		font-weight: 700;
		color: #fff;
	}
	.square:hover {
		border-radius: 50%;
	}
	.square:before {
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: #ccc;
		z-index: -1;
		transform: rotate(-45deg);
		border-radius: 10px;
	}
	.square p {
		height: 100%;
		color: #fff;
		font-size: 18px;
		font-weight: 700;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.square span {
		font-size: 14px;
		position: absolute;
		bottom: 5px;
		transform: rotate(-45deg);
	}
	.total-tiles, .total-box {
		padding-top: 50px;
		display: flex;
		width: 80%;
		margin: 0 auto;
	}
	.tiles-title, .box-title {
		width: 200px;
		height: 80px;
		border: 1px solid #ccc;
		font-size: 18px;
		font-weight: 600;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.tiles-num, .box-num {
		font-size: 18px;
		font-weight: 600;
		height: 80px;
		width: 80px;
		border: 2px solid #ccc;
		margin-left: 50px;
		box-shadow: 5px 5px 5px 0px #aaa, 10px 10px 5px 0px #000;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.left-tiles {
		margin-left: 50px;
		height: 80px;
		justify-content: center;
		align-items: center;
		display: none;
	}
	.calc-notice, .dim-tip {
		margin-top: 25px;
		font-family: cursive
	}
	.tiles-img {
		text-align: center;
	}
	.tip-title {
		
	}
	@media only screen and (max-width: 768px) {
		.total-box {
			flex-wrap: wrap;
		}
		.box-num {
			margin-right: 25px;
		}
		.left-tiles {
			margin-left: 0px;
			margin-top: 25px;
		}
	}
	@media only screen and (max-width: 568px) {
		.square:before {
			transform: rotate(90deg);
		}
		.square span {
			transform: rotate(0deg);
			width: 100%;
			left: 0;
			bottom: 20px;
		}
		.square p {
			height: 80%;
		}
		.area-title, .left-tiles, .tiles-title, .box-title {
			text-align: center;
		}
	}
	@media only screen and (max-width: 414px) {
		.calc-input, .total-area, .total-tiles, .total-tiles, .total-box {
			width: 100%;
		}
		.tiles-num, .box-num {
			margin-left: 40px;
		}
		.box-num {
			margin-right: 0px;
		}
		.total-area {
			flex-wrap: wrap;
		}
		.area-title {
			width: 100%;
			margin-bottom: 25px;
		}
	}
	@media only screen and (max-width: 380px) {
		.square {
			margin-left: 30px;
		}
		.tiles-title, .box-title, .left-tiles {
			width: 180px;
		}
		.tiles-num, .box-num {
			margin-left: 25px;
		}
	}
	</style>
	<div class="calc-container">
		<div class="input-title">Box Calculator</div>
		<div class="calc-input">
			<div style="margin-top: 20px;">
				<label>Length</label>
				<div class="tiles-length">
					<input type="number" min='1' name="length" class="length" placeholder="Feet" />
				</div>
			</div>
		</div>
		<div class="calc-input">
			<div style="margin-top: 20px;">
				<label>Width</label>
				<div class="tiles-width">
					<input type="number" min='1' name="width" class="width" placeholder="Feet" />
				</div>
			</div>
		</div>
		<div class="calc-input">
			<div style="margin-top: 20px;">
				<label>Tiles Size</label>
				<div class="select">
					<select id="mySelect">
						<option value="6/6">24" x 24" (600mm * 600mm)</option>
						<option value="3/6">12" x 24" (300mm * 600mm)</option>
						<option value="6/12">24" x 48" (600mm * 1200mm)</option>
						<option value="4/8">16" x 32" (400mm * 800mm)</option>
						<option value="2/12">8" x 48" (200mm * 1200mm)</option>
						<option value="1/3">4" x 12" (100mm * 300mm)</option>
						<option value="1/4">4" x 16" (100mm * 400mm)</option>
					</select>
					<i class='fas fa-arrow-alt-circle-down'></i>
				</div>
			</div>
			<div class="myButton">Calculate</div>
		</div>
	</div>
	<div class="calc-result">
		<div class="result-title">Calculations</div>
		<div class="total-area">
			<div class="area-title">Total Area Covered</div>
			<div class="square meter">
				<p></p>
				<span>Sq. M</span>
			</div>
			<div class="square feet">
				<p></p>
				<span>Sq. Ft</span>
			</div>
		</div>
		<div class="total-tiles">
			<div class="tiles-title">Required Tiles</div>
			<div class="tiles-num">X</div>
		</div>
		<div class="total-box">
			<div class="box-title">Required Boxes</div>
			<div class="box-num">X</div>
			<div class="left-tiles"></div>
		</div>
		<div class="calc-notice">
			<div>This may vary on basis of your actual need.</div>
			<div>This is only approx calculation.</div>
		</div>
	</div>
	<div class="tiles-img">
		<img src="<?php echo CTC_URL . 'assets/images/tiles.png'; ?>" />
	</div>
	<div class="calc-tips">
		<div class="tips-title">Tips</div>
		<div class="dim-tip">
			<div>Length and Width Dimensions are in feet.</div>
			<div>1 Feet = 0.3048 Meter</div>
			<div>1 Meter = 3.28084 Feet</div>
		</div>
	</div>
	<script>
	jQuery(document).ready(function(){
		jQuery('.myButton').click(function(){
			var length = jQuery('.length').val();
			var width = jQuery('.width').val();
			var tile = jQuery('#mySelect').val();
			var size = tile.split('/');
			var len; var wid; var cap;
			
			if(tile == '1/3' || tile == '1/4') {
				cap = 32;
			} else if(tile == '3/6' || tile == '4/8' || tile == '2/12') {
				cap = 5;
			} else if(tile == '6/6') {
				cap = 4;
			} else if(tile == '6/12') {
				cap = 2;
			}
			
			if(size[0] == 1){
				len = 0.328084;
			} else if(size[0] == 2){
				len = 0.656168;
			}else if(size[0] == 3){
				len = 0.984252;
			}else if(size[0] == 4){
				len = 1.31234;
			}else if(size[0] == 6){
				len = 1.9685;
			}else if(size[0] == 12){
				len = 3.937008;
			}
			
			if(size[1] == 1){
				wid = 0.328084;
			} else if(size[1] == 2){
				wid = 0.656168;
			}else if(size[1] == 3){
				wid = 0.984252;
			}else if(size[1] == 4){
				wid = 1.31234;
			}else if(size[1] == 6){
				wid = 1.9685;
			}else if(size[1] == 12){
				wid = 3.937008;
			}
			
			if(length > 0 && width > 0){
				var sqfeets = length*width;
				var sqmeters = sqfeets*0.0929506;
				
				if(sqfeets != Math.floor(sqfeets)) {
					sqfeets = sqfeets.toFixed(3);
				}
				if(sqmeters != Math.floor(sqmeters)) {
					sqmeters = sqmeters.toFixed(3);
				}
				
				jQuery('.square.meter p').text(sqmeters);
				jQuery('.square.feet p').text(sqfeets);
				
				
				var xlen = length/len;
				var ywid = width/wid;
				//xlen = Math.ceil(xlen);
				//ywid = Math.ceil(ywid);
				
				var ttiles = xlen*ywid;
				ttiles = Math.ceil(ttiles);
				jQuery('.tiles-num').text(ttiles);
				
				var tbox = ttiles/cap;
				tbox = Math.ceil(tbox);
				jQuery('.box-num').text(tbox);
				
				var totaltiles = tbox*cap;
				
				var lefttiles = totaltiles-ttiles;
				if(lefttiles > 0) {
					jQuery('.left-tiles').text('Extra tiles: '+ lefttiles);
					jQuery('.left-tiles').css('display', 'flex');
				} else {
					jQuery('.left-tiles').css('display', 'none');
				}
				
			} else {
				jQuery('.square.meter p').text('');
				jQuery('.square.feet p').text('');
				jQuery('.tiles-num').text('X');
				jQuery('.box-num').text('X');
				jQuery('.left-tiles').css('display', 'none');
			}
		});
	})
	</script>
	<?php
	return ob_get_clean();
}
add_shortcode( 'ctc_calculator', 'ctc_tiles_calculator' );