jQuery(document).ready(function(){
	jQuery("#setpassword").validate({
		rules: {
			ver_pass: {
				required: true,
				minlength: 5
			},
			ver_cpass : {
				required: true,
				minlength : 5,
				equalTo : "#ver_pass"
			},
		},
		messages: {
			ver_pass: {
				required: "Please provide a password",
				minlength: "Your password must be at least 5 characters long"
			},
			ver_cpass: {
				required: "Please provide a password",
				minlength: "Your password must be at least 5 characters long",
				equalTo: "Please enter the same password as above"
			}
		}
	});
	
	var wordLen = 100,
	len; // Maximum word length
	jQuery('#firstque').keydown(function(event) {	
		len = jQuery('#firstque').val().split(/[\s]+/);
		if (len.length > wordLen) { 
			if ( event.keyCode == 46 || event.keyCode == 8 ) {
				// Allow backspace and delete buttons
			} else if (event.keyCode < 48 || event.keyCode > 57 ) { //all other buttons
				event.preventDefault();
			}
		}
	});
	
	jQuery('.srt-approve').on('click', function(){
		var $this = jQuery(this);
		var actiontext = $this.text();
		var userid = $this.next().val();
		
		jQuery.ajax({
			type: 'POST',
			url: my_ajaxurl.ajax_url,
			data: {
				action: 'chg_shortlist',
				userid: userid
			},
			beforeSend: function(){
				if(actiontext == 'SHORTLIST'){
					$this.text("Shortlisting...");
				} else {
					$this.text("Removing...");
				}
			},
			success: function(response){
				console.log(response);
				if(response == 1){
					$this.text("REMOVE");
				} else {
					$this.text("SHORTLIST");
				}
			},
			error: function(response){
				console.log(response);
			},
		});
	});
	
	jQuery('.srt-vote').on('click', function(){
		var $this = jQuery(this);
		var userid = $this.next().val();
		
		jQuery('.chg-lightbox').css('display', 'flex');
		jQuery('.user_id').val(userid);
	});
	
	jQuery('.lb-close i').on('click', function(){
		jQuery('.vname').attr('value','');
		jQuery('.vemail').attr('value','');
		jQuery('.chg-lightbox').css('display', 'none');
	});
	
	jQuery('.vemail').on('keyup', function(){
		var vemail = jQuery(this).val();
		
		jQuery.ajax({
			type: 'POST',
			url: my_ajaxurl.ajax_url,
			data: {
				action: 'email_exist',
				vemail: vemail
			},
			success: function(response){
				console.log(response);
				if(response == 0){
					jQuery('.vsubmit').attr("disabled", false);
					jQuery('.err-vemail').hide();
				} else {
					jQuery('.vsubmit').attr("disabled", true);
					jQuery('.err-vemail').show();
				}
			},
			error: function(response){
				console.log(response);
			},
		});
	});
	
	//smooth scroll
	jQuery("a").on('click', function(event) {

		// Make sure this.hash has a value before overriding default behavior
		if (this.hash !== "") {
		  // Prevent default anchor click behavior
		  event.preventDefault();

		  // Store hash
		  var hash = this.hash;
			
		  // Using jQuery's animate() method to add smooth page scroll
		  // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
		  jQuery('html, body').animate({
			scrollTop: jQuery(hash).offset().top-100
		  }, 800, function(){

			// Add hash (#) to URL when done scrolling (default click behavior)
			//window.location.hash = hash;
			window.history.pushState({},"",hash);
		  });
		} // End if
	});
	
    /* Init DataTables */
	var istable = jQuery('#chg-raw-data').length;
	if( istable > 0 ){
		var oTable = jQuery('#chg-raw-data').dataTable();

		/* Apply the tooltips */
		oTable.$('.chg-raw-que').tooltip({
			"delay": 0,
			"track": true,
			"fade": 250
		});
	}
})