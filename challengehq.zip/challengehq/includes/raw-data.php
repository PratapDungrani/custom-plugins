<?php
/*
 * Display raw table data shortcode by Pratap
 *
 */
function chg_raw_data() {
	ob_start();
	wp_enqueue_script('chg-datatable-script');
	wp_enqueue_style('chg-datatable-style');
	
	//allow only Super admin to view this page
	if(current_user_can('administrator')) {
		global $wpdb;
		//$fields = $wpdb->get_results( "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '". CHG_TBL ."' ORDER BY ORDINAL_POSITION" );
		//$fields = json_decode(json_encode($fields), True);
		//echo '<pre>';
		//print_r($fields);
		$results = $wpdb->get_results( "SELECT * FROM ". CHG_TBL ." ORDER BY id ASC" );
		$results = json_decode(json_encode($results), True);
		//echo '<pre>';
		//print_r($results);
		
		?>
		<table id="chg-raw-data">
		<thead>
			<tr>	
				<th><?php _e('No.', CHG); ?></th>
				<th><?php _e('Team Name', CHG); ?></th>
				<th><?php _e('Team Leader', CHG); ?></th>
				<th><?php _e('Email', CHG); ?></th>
				<th><?php _e('1st Que', CHG); ?></th>
				<th><?php _e('2nd Que', CHG); ?></th>
				<th><?php _e('3rd Que', CHG); ?></th>
				<th><?php _e('Verified', CHG); ?></th>
				<th><?php _e('Video', CHG); ?></th>
				<th><?php _e('PDF', CHG); ?></th>
				<th><?php _e('Shorted', CHG); ?></th>
				<th><?php _e('Vote', CHG); ?></th>
			</tr>
		</thead>
		<tfoot>
			<tr>	
				<th><?php _e('No.', CHG); ?></th>
				<th><?php _e('Team Name', CHG); ?></th>
				<th><?php _e('Team Leader', CHG); ?></th>
				<th><?php _e('Email', CHG); ?></th>
				<th><?php _e('1st Que', CHG); ?></th>
				<th><?php _e('2nd Que', CHG); ?></th>
				<th><?php _e('3rd Que', CHG); ?></th>
				<th><?php _e('Verified', CHG); ?></th>
				<th><?php _e('Video', CHG); ?></th>
				<th><?php _e('PDF', CHG); ?></th>
				<th><?php _e('Shorted', CHG); ?></th>
				<th><?php _e('Vote', CHG); ?></th>
			</tr>
		</tfoot>
		<tbody>
			<?php
			$i = 1;
			foreach($results as $result){
			?>
				<tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $result['tname']; ?></td>
					<td><?php echo $result['tlname']; ?></td>
					<td><span title="<?php echo $result['tlemail']; ?>" class="chg-raw-que"><?php _e('View', CHG); ?></span></td>
					<td><span title="<?php echo $result['fque']; ?>" class="chg-raw-que"><?php _e('View', CHG); ?></span></td>
					<td><span title="<?php echo $result['sque']; ?>" class="chg-raw-que"><?php _e('View', CHG); ?></span></td>
					<td><span title="<?php echo $result['tque']; ?>" class="chg-raw-que"><?php _e('View', CHG); ?></span></td>
					<td><?php echo $result['verified']; ?></td>
					<td>
						<?php if($result['video'] != null){ ?>
							<a href="<?php echo $result['video']; ?>" target="_blank"><?php _e('Watch', CHG); ?></a>
						<?php } ?>
					</td>
					<td>
						<?php 
						if($result['pdf'] != null){
							$pdflink = content_url().'/uploads/challenge/'.$result['pdf']; 
						?>						
							<a href="<?php echo $pdflink; ?>" target="_blank" ><?php _e('View', CHG); ?></a>
						<?php } ?>
					</td>
					<td><?php echo $result['shorted']; ?></td>
					<td><?php echo $result['vote']; ?></td>
				</tr>
			<?php $i++; } ?>
		</tbody>
		</table>
	<?php	
	} else {
		//if not super admin
		?>
		<div class="chg-noexcess"><?php echo "You do not have permission to view this page."; ?></div>
		<?php
	}
	return ob_get_clean();
}
add_shortcode('raw_data', 'chg_raw_data');