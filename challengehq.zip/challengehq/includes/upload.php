<?php
if(isset($_POST['vdurl'])) {
	include_once( '../../../../wp-load.php' );
	global $wpdb;
	$table = $wpdb->prefix.'chg_team';

	// Upload directory
	$target_dir = '../../../uploads/challenge/';

	// Upload file
	$pdf = time().$_FILES["file"]["name"];
	$pdf_name = str_replace(' ', '-', $pdf);
	$pdf_name = str_replace("'", "", $pdf_name);
	$target_file = $target_dir.$pdf_name;
	$video_url = $_POST['vdurl'];
	$userid = $_POST['userid'];
	

	$msg = "";
		
	$wpdb->query("UPDATE ".$table." SET video = '".$video_url."', pdf = '".$pdf_name."' WHERE userid = ".$userid);
	//echo $wpdb->last_error;
	//echo $wpdb->last_query;
	//echo '<pre>';
	//print_r($wpdb);
	if($wpdb->rows_affected > 0){
		
		if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)){
			$msg = "Successfully uploaded";	
		} else {
			$msg = "Error while uploading";
		}
		
		$results = $wpdb->get_results("SELECT tlname, tlemail FROM ".$table." WHERE userid = ".$userid);
		$results = json_decode(json_encode($results), True);
		$result = $results[0];
		
		$username = $result['tlname'];
		$useremail = $result['tlemail'];
		
		$admin_email = 'challengehq@earthtech.io';
		$message = "<div>
						<p style='margin-bottom: 20px;'>Hi ".$username."</p>
						<p>Your entry has been submitted successfully.</p>
						<div style='margin-top: 50px;'>
							<p>Regards,</p>
							<p>The EarthTech Challenge Team</p>
						</div>
					</div>";

		//php mailer variables
		$to = $useremail;
		$subject = "Conformation of entry submission";
		$headers = 'From: '. $admin_email . "\r\n" .
				   'Reply-To: ' . $admin_email . "\r\n";

		//Here put your Validation and send mail
		$sent = wp_mail($to, $subject, $message, $headers);
		
		
	} else {
		$msg = "Database error";
	}
	echo $msg;
exit;
}