<?php
/**
 * public vote page shortcode
 *
 */
function chg_public_vote() {
	ob_start();
	
	//current page URL
	global $wp;
	$url = home_url( $wp->request );
	
	global $wpdb;
	$table = $wpdb->prefix.'chg_team';
	$vtable = $wpdb->prefix.'chg_voter';
	
	//on registering vote
	if(isset($_GET['rvote']) && $_GET['rvote'] == 'success'){
	?>
		<div class="chg-success"><h2><?php _e('Your email has been registered. Please verify your email to submit your vote.', CHG); ?></h2></div>
	<?php 
	//on database error
	} else if(isset($_GET['err']) && $_GET['err'] == 'database'){
	?>
		<div class="vote-err"><?php _e('Something went wrong. Please try again after sometime.', CHG); ?></div>
	<?php 
	//on verifcation link page
	} else if(isset($_GET['err']) && $_GET['err'] == 'duplicate'){
	?>
		<div class="vote-err"><?php _e('You have already registered.', CHG); ?></div>
	<?php 
	//on verifcation link page
	} else if(isset($_GET['vote']) && $_GET['vote'] != ''){		
		$vlink = $_GET['vote'];
		$results = $wpdb->get_results( "SELECT * FROM ".$vtable." WHERE vcode ='".$vlink."'" );
		$results = json_decode(json_encode($results), True);
		//$result = $results[0];
		//echo '<pre>';
		//print_r($result);
		if(!empty($results)) {
			$result = $results[0];
			$verified = $result['verified'];
			
			//if voted already
			if($verified == 'yes') {
				?>
					<div class="ver-msg"><h2><?php _e('You have already voted.', CHG); ?></h2></div>
				<?php
			} else {
				$vemail = $result['vemail'];
				$vname = $result['vname'];
				$userid = $result['userid'];
				
				$wpdb->query("UPDATE ".$vtable." SET verified = 'yes' WHERE vemail = '".$vemail."'");
				
				$success = $wpdb->rows_affected;
				$fail = $wpdb->last_error;
				
				//on successfull database update after registering vote
				if($success > 0 && $fail == ''){
					//vote count addition
					$wpdb->query("UPDATE ".$table." SET vote = vote + 1 WHERE userid = ".$userid);
				?>
					<div class="ver-msg"><h2><?php _e('Thanks for registering your vote. We will be announcing the winners on our social channels so make sure to follow us on Twitter, Facebook and Instagram.', CHG); ?></h2></div>
				<?php
				//email on successfull voting
					$admin_email = 'challengehq@earthtech.io';
					$message = "<div>
									<div style='margin-bottom: 20px;'>Hi ".$vname."</div>
									<div>Thanks for registering your vote. We will be announcing the winners on our social channels so make sure to follow us on Twitter, Facebook and Instagram.</div>
									<div style='margin-top: 50px;'>
										<p>Regards,</p>
										<p>The EarthTech Challenge Team</p>
									</div>
								</div>";

					//php mailer variables
					$to = $vemail;
					$subject = "Thank you for submitting your Vote for the EarthTech Challenge";
					$headers = 'From: '. $admin_email . "\r\n" .
							   'Reply-To: ' . $admin_email . "\r\n";

					//Here put your Validation and send mail
					$sent = wp_mail($to, $subject, $message, $headers);
				} else if($fail != ''){
					?>
					<div class="vote-err"><?php _e('Something went wrong. Please try again after sometime.', CHG); ?></div>
					<?php
				}
			}
		} else {
			//if verification link is invalid
			?>
			<div class="ver-msg-err"><?php _e('Invalid verification link.', CHG); ?></div>
			<?php
		}
	} else {
		
		$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE shorted = 'yes' ORDER BY tname ASC" );
		//echo '<pre>';
		//print_r($results);
		
		//if no records found
		if(empty($results)){
			?>
			<div class="srt-title"><h2><?php _e('No Entries Available', CHG); ?></h2></div>
			<?php
		} else {
			$results = json_decode(json_encode($results), True);
			//echo '<pre>';
			//print_r($results);
			$video_link = '';
			?>
			<div class="srt-container">
			<!--title-->
				<div class="srt-title"><h2><?php _e('EarthTech Challenge Public Vote for Shortlist', CHG); ?></h2></div>
			
				<!--sub title-->
				<div class="srt-subtitle"><?php _e('Congratulations to our Inaugural EarthTech Challenge entrants. View their anthem videos and vote for your favourite finalist. Your vote goes a long way to making the ideas here a reality.', CHG); ?></div>
				<div class="vote-guid">
					<div class="guide-title"><h3><?php _e('How the voting works', CHG); ?></h3></div>
					<div class="guide-subtitle"><?php _e('Voting is quick and easy! View the team videos below and click ‘VOTE” next to your favourite team. You will then be prompted to register your vote by verifying your email address. You can then share your vote and help back your favourite team! One vote per person.', CHG); ?></div>
				</div>
				<?php
				$find = array("\'",'\"');
				$replace = array("'", '"');
				$i = 1;
				foreach($results as $result) {
				?>
				<div class="srt-each-data" id="<?php echo sanitize_title($result['tname']).$i; ?>">
					<div class="srt-wrapper">
					<!--team name-->
						<div class="srt-subject">
							<h2><?php echo $result['tname']; ?></h2>
						</div>
						<!--video-->
						<div class="srt-details flx-row">
							<div class="srt-video">
							<?php
							$video_link = $result['video'];
							if(stristr($video_link, 'youtu') || stristr($video_link, 'vimeo')) {
								//if youtube video link
								if(stristr($video_link, 'youtu')) {
									preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $video_link, $match);
									$youtube_id = $match[1];
									$video_link = 'https://www.youtube.com/embed/'.$youtube_id.'?rel=0';
								} else if(stristr($video_link, 'vimeo')) {
									//if vimoe video link
									preg_match('%^https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)(?:[?]?.*)$%im', $video_link, $regs);
									$vimoe_id = $regs[3];
									$video_link = '//player.vimeo.com/video/'.$vimoe_id;
								}
							} else {
								$video_link = 'about:blank';
							}
							?>
								<iframe class="srt-vdframe" src="<?php echo $video_link; ?>" allowfullscreen="allowfullscreen"></iframe>
							</div>
							<div class="srt-description flx-col">
								<!--vote button-->
								<div class="srt-action flx-row">
									<div class="srt-vote"><?php _e('VOTE', CHG); ?></div>
									<input type="hidden" value="<?php echo $result['userid']; ?>" name="public_vote" class="public-vote" />
								</div>
								<!--description and answers of project-->
								<div class="srt-answers">
									<div class="srt-ans-desc">
										<div class="srt-que"><b><?php _e('Summarise your idea in 100 words or less', CHG); ?></b></div>
										<?php echo str_replace($find,$replace,$result['fque']); ?>
									</div>
									<div class="srt-ans-list">
										<div class="srt-ans">
											<div class="srt-que"><b><?php _e('What Global Goals are you targeting?', CHG); ?></b></div>
											<?php echo str_replace($find,$replace,$result['sque']); ?>
										</div>
										<div class="srt-ans">
											<div class="srt-que"><b><?php _e('Have you connected with the problem personally and what prompted you to find a solution?', CHG); ?></b></div>
											<?php echo str_replace($find,$replace,$result['tque']); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
				$i++;
				}
				?>
				
				<!--register vote popup-->
				<div class="chg-lightbox flx-col">
					<div class="chg-lb-container">
						<div class="lb-close"><i class="far fa-times-circle"></i></div>
						<div class="chg-lb-wrapper">
						<!--title-->
							<div class="lb-title"><h2><?php _e('REGISTER MY VOTE', CHG); ?></h2></div>
							<!--sub title-->
							<div class="lb-subtitle"><?php _e('Please enter your email address, and click ‘verify my vote’ on the email you receive. It may take a few minutes to be delivered.', CHG); ?></div>
							<!--register vote form-->
							<form method="POST" class="flx-col chg-field lb-vote">
								<input type="text" name="vname" placeholder="Enter you name" class="vname" required />
								<input type="email" name="vemail" placeholder="Enter you email" class="vemail" required />
								<div>
									<input type="submit" name="vsubmit" value="REGISTER MY VOTE" class="vsubmit" disabled />
									<input type="hidden" name="user_id" class="user_id" />
									<input type="hidden" name="red_url" value="<?php echo $url; ?>" />
									<div class="err-vemail"><?php _e('You have already voted.', CHG); ?></div>
								</div>
							</form>
							<!--privacy policy page link-->
							<div class="chg-policy"><?php _e('We take your privacy seriously. Read our Privacy Policy', CHG); ?></div>
						</div>
					</div>
				</div>
				
				<!--dropdown for list of teams-->
				<div class="chg-dropdown">
					<div class="chg-dd-opt"><?php _e('Select Team', CHG); ?></div>
					<div class="chg-dd-list">
						<?php
						$j = 1;
						foreach($results as $result) {
						?>
							<div class="chg-dd-option"><a href="<?php echo '#'.sanitize_title($result['tname']).$j; ?>" style="color: #333;"><?php echo $result['tname']; ?></a></div>
						<?php $j++; } ?>
					</div>
				</div>
				
			</div>
		<?php
		}
	}
	return ob_get_clean();
}
add_shortcode( 'public_vote', 'chg_public_vote' );


//ajax to verify email existance
function chg_email_exist() {
	$vemail = $_POST['vemail'];
	global $wpdb;
	$table = $wpdb->prefix.'chg_voter';
	$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE vemail = '".$vemail."'" );
	if(!empty($results)){
		echo "1";
	} else {
		echo "0";
	}
	
	exit;
}
add_action( 'wp_ajax_email_exist', 'chg_email_exist' );
add_action( 'wp_ajax_nopriv_email_exist', 'chg_email_exist' );


//ajax to register vote
function chg_register_vote() {
	if(isset($_POST['vsubmit'])) {
		$inputs = array();
		$inputs['userid'] = $_POST['user_id'];
		$inputs['vname'] = $_POST['vname'];
		$inputs['vemail'] = $_POST['vemail'];
		//verification code for verification link to vote
		$inputs['vcode'] = md5(uniqid(rand(), true));
		$url = $_POST['red_url'];
		//verification link to vote
		$vote_link = $url.'?vote='.$inputs['vcode'];
		
		global $wpdb;
		$table = $wpdb->prefix.'chg_voter';
		$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE vemail = '".$_POST['vemail']."'" );
		if(!empty($results)) {
			wp_safe_redirect($url.'?err=duplicate');
			exit();
		}
		
		$wpdb->insert( $table, $inputs, $format = null );
		$success = $wpdb->rows_affected;
		if($success > 0) {
			//send email on successfull database entry
			$admin_email = 'challengehq@earthtech.io';
			$message = "<div>
							<div style='margin-bottom: 20px;'>Hi ".$inputs['vname']."</div>
							<div>Thanks for registering your vote. Please click on the below link to confirm your vote.</div>
							<div>Confirmation link: <a href='".$vote_link."' target='_blank'>".$vote_link."</a></div>
							<div style='margin-top: 50px;'>
								<p>Regards,</p>
								<p>The EarthTech Challenge Team</p>
							</div>
						</div>";

			//php mailer variables
			$to = $inputs['vemail'];
			$subject = "Thank you for registering your Vote for the EarthTech Challenge";
			$headers = 'From: '. $admin_email . "\r\n" .
					   'Reply-To: ' . $admin_email . "\r\n";

			//Here put your Validation and send mail
			$sent = wp_mail($to, $subject, $message, $headers);
			
			wp_safe_redirect($url.'?rvote=success');
			exit();
		} else {
			wp_safe_redirect($url.'?err=database');
			exit();
		}
	}	
}
add_action('init', 'chg_register_vote');