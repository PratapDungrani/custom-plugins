<?php
/**
 * Register Profile form shortcode
 *
 */
function challenge_function() {
	ob_start();
	
	//get current page URL
	global $wp;
	$url = home_url( $wp->request );
	
	//database table
	global $wpdb;
	$table = $wpdb->prefix.'chg_team';
	
	//message on submitting profile
	if(isset($_GET['msg']) && $_GET['msg']== 'success'){
	?>
		<div class="chg-success"><h2><?php _e('Your details have been submitted. Please verify your email to confirm your profile creation.', CHG); ?></h2></div>
	<?php 
	//message on successfull password set and link verification
	} else if(isset($_GET['pass']) && $_GET['pass'] == 'success') {
	?>
		<div class="ver-msg"><h2><?php _e('Congratulations your profile is now created and you will be able to upload your submission on 20th January 2020.  Thanks from the EarthTech Challenge Team.', CHG); ?></h2></div>
	<?php
	//verify link if verification URL
	} else if(isset($_GET['verify']) && $_GET['verify'] != ''){
		$vlink = $_GET['verify'];
		$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE verify ='".$vlink."'" );
		$results = json_decode(json_encode($results), True);
		$result = $results[0];
		
		if(!empty($results)) {
			$verified = $result['verified'];
			// if link is already verified
			if($verified == 'yes') {
				?>
					<div class="ver-msg"><h2><?php _e('Your email has already been verified.', CHG); ?></h2></div>
				<?php
			//if link is not verified
			} else {
				$user_id = $result['userid'];
				$useremail = $result['tlemail'];
				$username =  $result['tlname'];
				
				//update table and set link verified
				$wpdb->query("UPDATE ".$table." SET verified = 'yes' WHERE tlemail = '".$useremail."'");
				//echo '<pre>';
				//print_r($wpdb);
				
				//set password form on link verification
				?>
				<form method="POST" id="setpassword">
					<div class="ver-container">
						<div class="ver-wrapper">
							<div class="ver-msg"><h2><?php _e('Congratulations your email has been verified.', CHG); ?></h2></div>
							<div class="ver-box">
							<!--Username-->
								<div class="ver-filed">
									<span><b><?php _e('User Name: ', CHG); ?></b></span><span><?php echo $useremail; ?></span>
								</div>
							<!--Password-->
								<div class="ver-filed flx-col">
									<span><?php _e('Password: ', CHG); ?></span>
									<span><input type="password" name="ver_pass" id="ver_pass" /></span>
								</div>
							<!--Conofirm Password-->
								<div class="ver-filed flx-col">
									<span><?php _e('Confirm Password: ',CHG); ?></span>
									<span><input type="password" name="ver_cpass" id="ver_cpass" /></span>
								</div>
								<div class="ver-filed ver-sbt">
									<input type="hidden" name="user_id" value="<?php echo $user_id; ?>" />
									<input type="hidden" name="user_email" value="<?php echo $useremail; ?>" />
									<input type="hidden" name="user_name" value="<?php echo $username; ?>" />
									<input type="hidden" name="err_rdt" value="<?php echo $url; ?>" /> <!--redirect page URL-->
									<input type="submit" name="ver_submit" value="Set Password" class="ver_submit" />
								</div>
							</div>
						</div>
					</div>
				</form>
				<?php
			}
		} else {
			//if verification link is not valid
			?>
				<div class="ver-msg-err"><?php _e('Invalid varification link.', CHG);?></div>
			<?php
		}
	} else {
	// Create profile form
	?>	
	<form method="POST">
		<div class="chg_contanier">
			<div class="chg-wrapper">
				<div class="chg_header">
				<!--title-->
					<div class="chg_title"><h2><?php _e('Create a profile', CHG); ?></h2></div>
					<!--sub title-->
					<div class="chg_subtitle"><?php _e('In preparation for your final submissions, you must complete the questions below.', CHG);?>
					<p><?php _e('Upload instructions will be sent to your email on the 20th January 2020.', CHG); ?></p>
					</div>
				</div>
				<div class="chg-profile">
					<?php
					//message if email is registered
					if(isset($_GET['err']) && $_GET['err']== 'email'){
					?>
					<div class="email-exist"><?php _e('You have already created Profile.', CHG); ?></div>
					<?php } ?>
					<?php
					// message if database error
					if(isset($_GET['err']) && $_GET['err']== 'database'){
					?>
					<div class="email-exist"><?php _e('Something went wrong. Please try again after sometime.', CHG); ?></div>
					<?php } ?>
					
					<!--team name-->
					<div class="flx-col chg-field">
						<label><?php _e('Team Name (or Individual Name)', CHG); ?></label>
						<input type="text" name="tname" value="" placeholder="Enter your text" class="" required/>
					</div>
					<!--team leader name-->
					<div class="flx-col chg-field">
						<label><?php _e('Team Leader’s Name', CHG); ?></label>
						<input type="text" name="tlname" value="" placeholder="Enter your text" class="" required/>
					</div>
					<!--team leader email-->
					<div class="flx-col chg-field">
						<label><?php _e("Team Leader's Email", CHG); ?></label>
						<input type="email" name="tlemail" value="" placeholder="Email" class="" required/>
					</div>
					<!--short description about project-->
					<div class="flx-col chg-field">
						<label><?php _e('Summarise your idea in 100 words or less', CHG); ?></label>
						<textarea row="5"  name="fque" placeholder="Enter your text" id="firstque" required/></textarea>
					</div>
					<!--Question-->
					<div class="flx-col chg-field">
						<label><?php _e('What Global Goals are you targeting?', CHG); ?></label>
						<textarea row="5"  name="sque" placeholder="Enter your text" required/></textarea>
					</div>
					<!--Question-->
					<div class="flx-col chg-field">
						<label><?php _e('Have you connected with the problem personally and what prompted you to find a solution?', CHG); ?></label>
						<textarea row="5"  name="tque" placeholder="Enter your text" required/></textarea>
					</div>
				</div>
				<div class="submit-profile">
					<input type="submit" name="submit_profile" value="SUBMIT" class="submit_profile" />
					<input type="hidden" name="err_redirect" value="<?php echo $url; ?>" /> <!--redirect page URL-->
					<div class="chg_subtitle"><?php _e('You will be sent an email to verify your account. Please check email to continue and confirm your profile creation.', CHG); ?></div>
				</div>
			</div>
		</div>
	</form>
	<?php
	}
	return ob_get_clean();
}
add_shortcode( 'challenge_form', 'challenge_function' );

// insert data into database on creating profile
function insert_team_profile() {
	if(isset($_POST['submit_profile'])) {
		global $wpdb;
		$inputs = array();
		$inputs['tname']   = $_POST['tname'];
		$inputs['tlname']  = $_POST['tlname'];
		$inputs['tlemail'] = $_POST['tlemail'];
		$inputs['fque']    = $_POST['fque'];
		$inputs['sque']    = $_POST['sque'];
		$inputs['tque']    = $_POST['tque'];
		$tlname 		   = $_POST['tlname'];
		$tlemail		   = $_POST['tlemail'];
		$table 			   = $wpdb->prefix.'chg_team';
		$usertable = $wpdb->prefix.'users';
		
		$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE tlemail ='".$tlemail."'" );
		$userexist = $wpdb->get_results( "SELECT ID FROM ".$usertable." WHERE user_email ='".$tlemail."'" );
		
		$url = $_POST['err_redirect'];
		
		//if email exist in challenge table
		if(!empty($results)) {
			wp_safe_redirect($url.'?err=email');
			exit();
		} else {
			//insert query
			$wpdb->insert( $table, $inputs, $format = null );
			
			
			$success = $wpdb->rows_affected;
			//if successfull
			if($success > 0) {
				
				//create random password
				$pass = md5(uniqid(rand(), true));
				
				//create random verification code
				$verf_para = md5(uniqid(rand(), true));
				
				//create verification link
				$cfn_link = $url.'?verify='.$verf_para;
				
				//if user exist in user table
				$user_id = '';
				if(!empty($userexist)) {
					$userexist = json_decode(json_encode($userexist), True);
					$isuser = $userexist[0];
					$user_id = $isuser['ID'];
				} else {
					//create wordpress user
					$user_id = wp_create_user( $tlemail, $pass, $tlemail );
				}
				
				//update table and insert verification code and user id
				$wpdb->query("UPDATE ".$table." SET userid = ".$user_id.", verify = '".$verf_para."' WHERE tlemail = '".$tlemail."'");
				
				
				//send email to user
				//$admin_email = get_option( 'admin_email');
				$admin_email = 'challengehq@earthtech.io';
				$message = "<div>
								<div style='margin-bottom: 20px;'>Hi ".$tlname."</div>
								<div>Thanks for creating your profile to submit your entry to the EarthTech Challenge. Please click on the link below to verify your email and create your account.</div>
								<div>Verification link: <a href='".$cfn_link."' target='_blank'>".$cfn_link."</a></div>
								<div style='margin-top: 20px;'>When you click the link it will ask you to enter the password for the website. The password is: <b>m@ke1mpact</b></div>
								<div style='margin-top: 50px;'>
									<p>Regards,</p>
									<p>The EarthTech Challenge Team</p>
								</div>
							</div>";

				//php mailer variables
				$to = $tlemail;
				$subject = "Thank you for registering your Profile for the EarthTech Challenge";
				$headers = 'From: '. $admin_email . "\r\n" .
						   'Reply-To: ' . $admin_email . "\r\n";

				//Here put your Validation and send mail
				$sent = wp_mail($to, $subject, $message, $headers);
				
				wp_safe_redirect($url.'?msg=success');
				exit();
			} else {
				//if database error
				wp_safe_redirect($url.'?err=database');
				exit();
			}
		}
	}
	
	//on verification link page
	if(isset($_POST['ver_submit'])){
		
		$userid    = $_POST['user_id'];
		$pass      = $_POST['ver_pass'];
		$useremail = $_POST['user_email'];
		$username  = $_POST['user_name'];
		$url 	   = $_POST['err_rdt'];
		
		//set password
		wp_set_password( $pass, $userid );
		
		//send email on successfull password set and verification
		//$admin_email = get_option( 'admin_email');
		$admin_email = 'challengehq@earthtech.io';
		$message = "<div>
						<div style='margin-bottom: 20px;'>Hi ".$username."</div>
						<div>Your account has been created successfully.</div>
						<div style='margin-top: 50px;'>
							<p>Regards,</p>
							<p>The EarthTech Challenge Team</p>
						</div>
					</div>";

		//php mailer variables
		$to = $useremail;
		$subject = "Confirmation of account creation";
		$headers = 'From: '. $admin_email . "\r\n" .
				   'Reply-To: ' . $admin_email . "\r\n";

		//Here put your Validation and send mail
		$sent = wp_mail($to, $subject, $message, $headers);
		
		wp_safe_redirect($url.'?pass=success');
		exit();
	}
}
add_action('init', 'insert_team_profile');