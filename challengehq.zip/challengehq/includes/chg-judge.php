<?php
/**
 * Display shortlisted profile for judging shortcode by Pratap
 *
 */
function judge_opinion() {
	ob_start();
	
	//if(current_user_can('administrator')) {
		global $wpdb;
		$table = $wpdb->prefix.'chg_team';
		$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE shorted = 'yes' ORDER BY tname ASC" );
		//echo '<pre>';
		//print_r($results);
		
		if(empty($results)){
			//if no records found
			?>
			<div class="srt-title"><h2><?php _e('No Entries Available', CHG); ?></h2></div>
			<?php
		} else {
			$results = json_decode(json_encode($results), True);
			//echo '<pre>';
			//print_r($results);
			$video_link = '';
			$srt_txt = '';
			$pdflink = '';
			?>
			<div class="srt-container">
			<!--title-->
				<div class="srt-title"><h2><?php _e('EarthTech Challenge Shortlist Judging Portal', CHG); ?></h2></div>
				<!--sub title-->
				<div class="srt-subtitle"><?php _e('Thanks judges for your time in helping choose the winning teams for the EarthTech Challenge. Please log into AVVA, choose the team, answer the questions relating to the team, and submit.', CHG); ?></div>
				<?php
				$find = array("\'",'\"');
				$replace = array("'", '"');
				$i = 1;
				foreach($results as $result) {
				?>
				<div class="srt-each-data" id="<?php echo sanitize_title($result['tname']).$i; ?>">
					<div class="srt-wrapper">
					<!--team name-->
						<div class="srt-subject">
							<h2><?php echo $result['tname']; ?></h2>
						</div>
						<!--video-->
						<div class="srt-details flx-row">
							<div class="srt-video">
							<?php
							$video_link = $result['video'];
							if(stristr($video_link, 'youtu') || stristr($video_link, 'vimeo')) {
								//if youtube video link
								if(stristr($video_link, 'youtu')) {
									preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $video_link, $match);
									$youtube_id = $match[1];
									$video_link = 'https://www.youtube.com/embed/'.$youtube_id.'?rel=0';
								} else if(stristr($video_link, 'vimeo')) {
									//if vimoe video link
									preg_match('%^https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)(?:[?]?.*)$%im', $video_link, $regs);
									$vimoe_id = $regs[3];
									$video_link = '//player.vimeo.com/video/'.$vimoe_id;
								}
							} else {
								$video_link = 'about:blank';
							}
							?>
								<iframe class="srt-vdframe" src="<?php echo $video_link; ?>" allowfullscreen="allowfullscreen"></iframe>
							</div>
							<div class="srt-description flx-col">
							<!--description and answers of project-->
								<div class="srt-answers">
									<div class="srt-ans-desc">
										<div class="srt-que"><b><?php _e('Summarise your idea in 100 words or less', CHG); ?></b></div>
										<?php echo str_replace($find,$replace,$result['fque']); ?>
									</div>
									<div class="srt-ans-list">
										<div class="srt-ans">
											<div class="srt-que"><b><?php _e('What Global Goals are you targeting?', CHG); ?></b></div>
											<?php echo str_replace($find,$replace,$result['sque']); ?>
										</div>
										<div class="srt-ans">
											<div class="srt-que"><b><?php _e('Have you connected with the problem personally and what prompted you to find a solution?', CHG); ?></b></div>
											<?php echo str_replace($find,$replace,$result['tque']); ?>
										</div>
									</div>
								</div>
								<!--view pdf button-->
								<div class="srt-action flx-row">
								<?php 
									$pdflink = content_url().'/uploads/challenge/'.$result['pdf'];
								?>
									<div class="srt-viewpdf"><a href="<?php echo $pdflink; ?>" target="_blank"><?php _e('VIEW SUPPORTING DOCUMENT', CHG); ?></a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
				$i++;
				}
				?>
			</div>
			
			<!--dropdown for list of teams-->
			<div class="chg-dropdown">
				<div class="chg-dd-opt"><?php _e('Select Team', CHG); ?></div>
				<div class="chg-dd-list">
					<?php
					$j = 1;
					foreach($results as $result) {
					?>
						<div class="chg-dd-option"><a href="<?php echo '#'.sanitize_title($result['tname']).$j; ?>" style="color: #333;"><?php echo $result['tname']; ?></a></div>
					<?php $j++; } ?>
				</div>
			</div>
		<?php
		}
	/*} else {
		?>
		<div class="chg-noexcess"><?php echo "You do not have permission to view this page."; ?></div>
		<?php
	}*/
	
	return ob_get_clean();
}
add_shortcode( 'judge_opinion', 'judge_opinion' );