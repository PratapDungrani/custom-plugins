<?php
/*
 * Short list profile shortcode by Pratap
 *
 */
function short_list_profile() {
	ob_start();
	
	//allow only Super admin to view this page
	if(current_user_can('administrator')) {
		global $wpdb;
		$table = $wpdb->prefix.'chg_team';
		$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE pdf <> '' AND verified <> '' ORDER BY id ASC" );
		//echo '<pre>';
		//print_r($results);
		
		//if no records found
		if(empty($results)){
			?>
			<div class="srt-title">
				<h2><?php _e('No Entries Available', CHG); ?></h2>
			</div>
			<?php
		} else {
			$results = json_decode(json_encode($results), True);
			//echo '<pre>';
			//print_r($results);
			$video_link = '';
			$srt_txt = '';
			$pdflink = '';
			?>
			<div class="srt-container">
			<!--title-->
				<div class="srt-title"><h2><?php _e('EarthTech Challenge - Make Shortlist', CHG); ?></h2></div>
				<!--sub title-->
				<div class="srt-subtitle"><?php _e('For internal EarthTech use only. Click ‘shortlist’ on the teams who will become finalists.', CHG); ?></div>
				<?php
				$find = array("\'",'\"');
				$replace = array("'", '"');
				$i = 1;
				foreach($results as $result) {
				?>
				<div class="srt-each-data" id="<?php echo sanitize_title($result['tname']).$i; ?>">
					<div class="srt-wrapper">
					<!--team name-->
						<div class="srt-subject">
							<h2><?php echo $result['tname']; ?></h2>
						</div>
						<!--video-->
						<div class="srt-details flx-row">
							<div class="srt-video">
							<?php
							$video_link = $result['video'];
							if(stristr($video_link, 'youtu') || stristr($video_link, 'vimeo')) {
								//if youtube video link
								if(stristr($video_link, 'youtu')) {
									preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $video_link, $match);
									$youtube_id = $match[1];
									$video_link = 'https://www.youtube.com/embed/'.$youtube_id.'?rel=0';
								} else if(stristr($video_link, 'vimeo')) {
									//if vimoe video link
									preg_match('%^https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)(?:[?]?.*)$%im', $video_link, $regs);
									$vimoe_id = $regs[3];
									$video_link = '//player.vimeo.com/video/'.$vimoe_id;
								}
							} else {
								$video_link = 'about:blank';
							}
							?>
								<iframe class="srt-vdframe" src="<?php echo $video_link; ?>" allowfullscreen="allowfullscreen"></iframe>
							</div>
							<div class="srt-description flx-col">
							<!--description and answers of project-->
								<div class="srt-answers">
									<div class="srt-ans-desc">
										<div class="srt-que"><b><?php _e('Summarise your idea in 100 words or less', CHG); ?></b></div>
										<?php echo str_replace($find,$replace,$result['fque']); ?>
									</div>
									<div class="srt-ans-list">
										<div class="srt-ans">
											<div class="srt-que"><b><?php _e('What Global Goals are you targeting?', CHG); ?></b></div>
											<?php echo str_replace($find,$replace,$result['sque']); ?>
										</div>
										<div class="srt-ans">
											<div class="srt-que"><b><?php _e('Have you connected with the problem personally and what prompted you to find a solution?', CHG); ?></b></div>
											<?php echo $str_replace($find,$replace,$result['tque']); ?>
										</div>
									</div>
								</div>
								<!--view pdf and short list button-->
								<div class="srt-action flx-row">
								<?php 
									$pdflink = content_url().'/uploads/challenge/'.$result['pdf'];
									//view pdf button
								?>
									<div class="srt-viewpdf"><a href="<?php echo $pdflink; ?>" target="_blank"><?php _e('VIEW SUPPORTING DOCUMENT', CHG); ?></a></div>
									<?php
									if($result['shorted'] == ''){
										$srt_txt = 'SHORTLIST';
									} else if($result['shorted'] == 'yes') {
										$srt_txt = 'REMOVE';
									}
									//short list button
									?>
									<div class="srt-approve"><?php echo $srt_txt; ?></div>
									<input type="hidden" name="userid" value="<?php echo $result['userid']; ?>" />
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
				$i++;
				}
				?>
			</div>
			
			<!--dropdown for list of teams-->
			<div class="chg-dropdown admin">
				<div class="chg-dd-opt"><?php _e('Select Team', CHG); ?></div>
				<div class="chg-dd-list">
					<?php
					$j = 1;
					foreach($results as $result) {
					?>
						<div class="chg-dd-option"><a href="<?php echo '#'.sanitize_title($result['tname']).$j; ?>" style="color: #333;"><?php echo $result['tname']; ?></a></div>
					<?php $j++; } ?>
				</div>
			</div>
		<?php
		}
	} else {
		//if not super admin
		?>
		<div class="chg-noexcess"><?php echo "You do not have permission to view this page."; ?></div>
		<?php
	}
	return ob_get_clean();
}
add_shortcode( 'short_list', 'short_list_profile' );


//ajax to shortlist/Remove candidate
function chg_shortlist() {
	global $wpdb;
	$table = $wpdb->prefix.'chg_team';
	$userid = $_POST['userid'];
	$results = $wpdb->get_results( "SELECT shorted FROM ".$table." WHERE userid = ".$userid);
	$results = json_decode(json_encode($results), True);
	
	//remove from shortlist
	if($results[0]['shorted'] == 'yes') {
		$wpdb->query("UPDATE ".$table." SET shorted = '' WHERE userid = ".$userid);
		$update = $wpdb->rows_affected;
		if($update > 0) {
			echo '0';
		}
	} else {
		//shortlist
		$wpdb->query("UPDATE ".$table." SET shorted = 'yes' WHERE userid = ".$userid);
		$update = $wpdb->rows_affected;
		if($update > 0) {
			echo '1';
		}
	}
	die;
}
add_action( 'wp_ajax_chg_shortlist', 'chg_shortlist' );
add_action( 'wp_ajax_nopriv_chg_shortlist', 'chg_shortlist' );