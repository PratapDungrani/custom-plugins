<?php
/**
 * List voters shortcode by Pratap
 *
 */
function list_total_vote() {
	ob_start();
	
	//view only if user is super admin
	if(current_user_can('administrator')) {
		global $wpdb;
		$table = $wpdb->prefix.'chg_team';
		$vtable = $wpdb->prefix.'chg_voter';
		$results = $wpdb->get_results( "SELECT * FROM ".$table." WHERE shorted = 'yes'" );
		
		//if no records found
		if(empty($results)){
		?>
			<div class="srt-title"><h2><?php _e('No Entries Available', CHG); ?></h2></div>
		<?php
		} else {
			$results = json_decode(json_encode($results), True);
			//echo '<pre>';
			//print_r($results);
		?>
			<div class="vt-container">
				<div class="vt-wrapper">
				<?php
				foreach($results as $result){
					$userid = $result['userid'];
				?>
					<div class="vt-each-team">
						<div class="vt-team-info flx-row">
							<div class="vt-tm-name"><?php echo $result['tname']; ?></div>
							<div class="vt-total-vote"><?php _e('Votes: ', CHG); ?><?php echo $result['vote']; ?></div>
						</div>
						<?php
						//voter list
						$voters = $wpdb->get_results( "SELECT * FROM ".$vtable." WHERE verified ='yes' AND userid = ".$userid );
						//echo '<pre>';
						//print_r($voters);
						if(!empty($voters)) {
							$voters = json_decode(json_encode($voters), True);
							foreach($voters as $voter){
							?>
							<div class="vt-voter-info flx-row">
								<div class="vt-name"><?php echo $voter['vname']; ?></div>
								<div class="vt-email"><?php echo $voter['vemail']; ?></div>
							</div>
							<?php 
							}
						} else {
							?>
							<div class="vt-voter-info"><?php _e('No Voters', CHG); ?></div>
							<?php
						}
						?>
					</div>
				<?php } 
					$totalvote = $wpdb->get_results( "SELECT COUNT(*) FROM ".$vtable." WHERE verified ='yes' ");
					$totalvote = $totalvote[0];
					$totalvote = json_decode(json_encode($totalvote), True);
					?>
					<div style="padding: 10px 20px;font-size: 24px;background-color: #0d3c57;color: #fff;font-weight: 500;line-height: 32px;letter-spacing: 1px;">
						<span><?php _e('Total votes = ', CHG); echo $totalvote['COUNT(*)'];?></span> 
					</div>
				</div>
			</div>
		<?php
		}
	} else {
		?>
		<div class="chg-noexcess"><?php echo "You do not have permission to view this page."; ?></div>
		<?php
	}
	return ob_get_clean();
}
add_shortcode( 'view_voters', 'list_total_vote' );