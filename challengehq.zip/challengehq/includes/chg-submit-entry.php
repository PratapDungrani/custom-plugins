<?php
/**
 * Submit entry form shortcode by Pratap
 *
 */
function submit_entry_function() {
	ob_start();
	global $wpdb;

	//allow only logged in user to submit entry
	if(is_user_logged_in()){
		
		//current user id
		$userid = get_current_user_id();

		$isverified = $wpdb->get_results("SELECT verified FROM ".CHG_TBL." WHERE userid = ".$userid);
		
		if(!empty($isverified) || current_user_can('administrator')){
			$isverified = json_decode(json_encode($isverified), True);
			$verified = $isverified[0];
			
			if($verified['verified'] == 'yes' || current_user_can('administrator')) {		
		
				//current page URL
				global $wp;
				$url = home_url( $wp->request );
				
				//on successfull entry submission
				if(isset($_GET['entry']) && $_GET['entry'] == 'success') {
				?>
					<div class="chg_title"><h2><?php _e('Your entry has been submitted successfully.', CHG); ?></h2></div>
				<?php
				//on databse error while submitting entry
				} else if(isset($_GET['entry']) && $_GET['entry'] == 'dberror') {
				?>
					<div class="entry-err"><?php _e('Sorry could not update your data. Please try again later.', CHG); ?></div>
				<?php
				//on file upload error while submitting entry
				} else if(isset($_GET['entry']) && $_GET['entry'] == 'fileerror') {
				?>
					<div class="entry-err"><?php _e('Failed to upload file. Please try again later.', CHG); ?></div>
				<?php
				} else {
				?>
					<script>
					Dropzone.options.myDropzone= {
						url: '<?php echo CHG_URL; ?>/includes/upload.php',
						autoProcessQueue: false,
						uploadMultiple: false,
						parallelUploads: 1,
						maxFiles: 1,
						maxFilesize: 50,
						acceptedFiles: 'application/pdf',
						addRemoveLinks: true,
						init: function() {
							dzClosure = this; // Makes sure that 'this' is understood inside the functions below.

							// for Dropzone to process the queue (instead of default form behavior):
							document.getElementById("submit-all").addEventListener("click", function(e) {
								// Make sure that the form isn't actually being sent.
								e.preventDefault();
								e.stopPropagation();
								
								//video link field verification
								var videourl = jQuery("#videourl").val()
								if( videourl != ''){
									var youtu = "https://youtu.be/";
									var youtube = "https://www.youtube.com/";
									var vimeo = "https://vimeo.com/";
									
									//if valid video link
									if(videourl.indexOf(youtu) != -1 || videourl.indexOf(youtube) != -1 || videourl.indexOf(vimeo) != -1){
										jQuery('.not-video').hide();
										jQuery('.empty-video').hide();
										
										//run upload process
										dzClosure.processQueue();
										
									//if invalid video 
									} else { 
										jQuery('.not-video').show();
										jQuery('.empty-video').hide();
									}
									
								//if no video link
								} else { 
									jQuery('.not-video').hide();
									jQuery('.empty-video').show();
								}	
							});
							//send all the form data along with the files:
							this.on("sending", function(data, xhr, formData) {
								formData.append("vdurl", jQuery("#videourl").val());
								formData.append("userid", jQuery("#user_id").val());
							});
							//redirection based on output
							this.on('success', function (file, json) {
								var succes = json;
								if (file.accepted == true && succes == 'Successfully uploaded') {
									window.location.href = '<?php echo $url; ?>?entry=success';
								} else if (file.accepted == true && succes == 'Database error') {
									window.location.href = '<?php echo $url; ?>?entry=dberror';
								} else if (file.accepted == true && succes == 'Error while uploading') {
									window.location.href = '<?php echo $url; ?>?entry=fileerror';
								}
							});
						}
					}
					</script>
					<!--submit entry form-->
					<form action="upload.php" enctype="multipart/form-data" method="POST">
						<div class="chg_contanier">
							<div class="chg-wrapper">
								<div class="chg_header">
									<!--warinng if page viewed by admin-->
									<?php if(current_user_can('administrator')){ ?>
										<div class="admin-warning"><?php _e('As an "Admin" you cannot submit entry.', CHG); ?></div>
									<?php } ?>
									<!--title-->
									<div class="chg_title"><h2><?php _e('Submit your entry', CHG); ?></h2></div>
									<!--subtitles-->
									<div class="chg_subtitle"><?php _e('In order to submit your entry, you need to upload your video (of up to 5 minutes) to your youtube channel. ', CHG); ?><a href="<?php echo site_url().'/how-to-submit-your-entry/'; ?>"><?php _e('Click here for instructions.', CHG); ?></a></div>
									<div class="chg_subtitle"><?php _e('Note that if your submission is shortlisted, the video will be made public, but not the PDF document. If there is anything you don’t want shared publicly, don’t add it to the video, but you can keep it in the PDF document.', CHG); ?></div>
								</div>
								<div class="chg-entry">
								<!--video link field-->
									<div class="flx-col chg-field">
										<label><?php _e('Anthem Video Link (manditory) ', CHG); ?><a href="<?php echo site_url().'/anthem-video/'; ?>"><?php _e('What is an Anthem Video?', CHG); ?></a></label>
										<input type="text" name="vdurl" placeholder="Enter Video URL" id="videourl" />
										<div class="empty-video"><?php _e('Please enter video URL.'); ?></div>
										<div class="not-video"><?php _e('Please enter valid video URL.'); ?></div>
									</div>
								<!--file upload field-->
									<div class="flx-col chg-field">
										<label><?php _e('Supporting Document (PDF format only) ', CHG); ?><a href="<?php echo site_url().'/supporting-documentation/'; ?>"><?php _e('What is the supporting document?', CHG); ?></a></label>
										<div class="dropzone chg-field" id="myDropzone">
											<div class="dz-default dz-message">
												<span><?php _e('Drop Files Here', CHG); ?></span>
												<div class="chg-plus"><?php _e('+', CHG); ?></div>
											</div>	
										</div>
									</div>
									<!--show submit button if page not viewed by admin-->
									<?php if(current_user_can('administrator')){ ?>
										<input type="submit" name="disable_submit" value="SUBMIT" disabled />
									<?php } else { ?>
										<input type="submit" name="submit_entry" value="SUBMIT" id="submit-all" />
									<?php } ?>									
									<input type="hidden" name="userid" value="<?php echo $userid; ?>" id="user_id" />
								</div>
							</div>
						</div>
					</form>
				<?php
				}
			} else {
				//if user has not verified email
				?>
					<div class="entry-err"><?php _e('Please verify your email to submit entry.', CHG); ?></div>
				<?php
			}
		} else {
			//if user is logged in but not created profile
			?>
				<div class="entry-err"><?php _e('Please create profile to submit entry.', CHG); ?></div>
			<?php
		}
	} else {
		//if user is not logged in
		?>
			<div class="entry-err"><?php _e('Please login to access this page.', CHG); ?></div>
		<?php
	}
	return ob_get_clean();
}
add_shortcode( 'submit_entry', 'submit_entry_function' );