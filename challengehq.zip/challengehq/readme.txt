Below is the list of short code to display forms and data.

[challenge_form]	=> Display "Create profile" form.
[submit_entry]		=> Display "Submit Entry" form for registered participants.
[short_list]		=> Display all participants information in order to shortlist by admin.
[judge_opinion]		=> Display shortlisted participant for judging.
[public_vote]		=> Display shortlisted participants for Public vote.
[view_voters]		=> Display participant vote count with voter's information.