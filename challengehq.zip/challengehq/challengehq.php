<?php
/**
 * Plugin Name: Challengehq
 * Plugin URI: https://wordpress.org/plugins/
 * Description: Create challenges.
 * Version: 1.0
 * Author: Pratap
 * Author URI: 
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Text Domain: challengehq
 * Domain Path: /languages/
 */
/*
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
    exit;
}

/*
 * Define variables
 */
global $wpdb;
define('CHG_FILE', __FILE__);
define('CHG_DIR', plugin_dir_path(CHG_FILE));
define('CHG_URL', plugins_url('/', CHG_FILE));
define('CHG', 'challengehq');
define('CHG_TBL', $wpdb->prefix . "chg_team" );
define('CHG_VTBL', $wpdb->prefix . "chg_voter" );

/**
 * Main Plugin CHG class.
 */
class CHG_Class {

    /**
     * CHG constructor.
     */
    public function __construct() {
        $this->chg_hooks();
        $this->chg_include_files();
    }

    /**
     * Initialize hooks
     */
    public function chg_hooks() {
		add_action('activate_plugin', array($this, 'chg_create_table'));
		add_action('activate_plugin', array($this, 'chg_challenge_pdf'));
        add_action('plugins_loaded', array($this, 'chg_load_language_files'));
        add_action('admin_enqueue_scripts', array($this, 'chg_admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'chg_user_scripts'));
		
		// Hooking up our functions to WordPress filters to change email sender name
		add_filter( 'wp_mail_from',  array($this, 'chg_sender_email' ));
		add_filter( 'wp_mail_from_name', array($this, 'chg_sender_name' ));
		//html-css formating
		add_filter ("wp_mail_content_type", array($this, "chg_mail_content_type"));
    }

    /**
     * Include required files
     */
    public function chg_include_files() {
        include_once( CHG_DIR . 'includes/chg-profile-form.php' );
		include_once( CHG_DIR . 'includes/chg-submit-entry.php' );
		include_once( CHG_DIR . 'includes/chg-short-list.php' );
		include_once( CHG_DIR . 'includes/chg-judge.php' );
		include_once( CHG_DIR . 'includes/chg-public-vote.php' );
		include_once( CHG_DIR . 'includes/chg-vote-count.php' );
		include_once( CHG_DIR . 'includes/raw-data.php' );
		include_once( CHG_DIR . 'includes/upload.php' );
    }

    /**
     * Loads plugin textdomain
     */
    public function chg_load_language_files() {
        load_plugin_textdomain(CHG, false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /**
     *
     * Enqueue admin panel required css/js
     */
    public function chg_admin_scripts() {

        wp_register_style('chg-admin-style', CHG_URL . 'assets/css/admin-style.css');
		wp_enqueue_style('chg-admin-style');

        wp_register_script('chg-admin-script', CHG_URL . 'assets/js/admin-script.js', array('jquery'), false, true);
        wp_enqueue_script('chg-admin-script');
		
    }

	/**
     *
     * Enqueue user panel required css/js
     */
    public function chg_user_scripts() {

        wp_register_style('chg-user-style', CHG_URL . 'assets/css/user-style.css');
		wp_enqueue_style('chg-user-style');

		wp_register_script('chg-user-script', CHG_URL . 'assets/js/user-script.js', array('jquery'), false, true);
        wp_enqueue_script('chg-user-script');
		
		wp_enqueue_script('chg-validate-script', CHG_URL . 'assets/js/jquery.validate.js');

		wp_enqueue_script('chg-tooltip-script', CHG_URL . 'assets/js/chg-tooltip.js');
		
		wp_localize_script( 'chg-user-script', 'my_ajaxurl', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
		wp_enqueue_style( 'font-awesome-free', '//use.fontawesome.com/releases/v5.2.0/css/all.css' );
		
		wp_enqueue_script('chg-dropzone-script', 'https://rawgit.com/enyo/dropzone/master/dist/dropzone.js');	
		wp_enqueue_style('chg-dropzone-style', 'https://rawgit.com/enyo/dropzone/master/dist/dropzone.css');
		
		wp_localize_script( 'chg-user-script', 'my_ajaxurl', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
		
		wp_register_script('chg-datatable-script', 'http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js');
		wp_register_style('chg-datatable-style', 'http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css');
		
		wp_enqueue_script('chg-recaptcha-script', 'https://www.google.com/recaptcha/api.js?render=_reCAPTCHA_6Le7ZdMUAAAAAD6b5j9o8V0DtcGVZtVWCsWG849K');
    }

	/**
     *
     * Create required table
     */
    public function chg_create_table() {

		global $wpdb;
        if ( $wpdb->get_var('SHOW TABLES LIKE " . CHG_TBL . "') != CHG_TBL ) {
            $sql = "CREATE TABLE " . CHG_TBL . " (
				id int(11) NOT NULL AUTO_INCREMENT,
				tname varchar(255) NOT NULL,
				tlname varchar(255) NOT NULL,
				tlemail varchar(255) NOT NULL,
				fque text NOT NULL,
				sque text NOT NULL,
				tque text NOT NULL,
				userid int(11) NOT NULL,
				verify varchar(255) NOT NULL,
				verified varchar(255) NOT NULL,
				video varchar(255) NOT NULL,
				pdf varchar(255) NOT NULL,
				shorted varchar(255) NOT NULL,
				vote int(11) NOT NULL,
				created_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			    PRIMARY KEY (id))";
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
	    }
		
		if ( $wpdb->get_var('SHOW TABLES LIKE " . CHG_VTBL . "') != CHG_VTBL ) {
            $sql = "CREATE TABLE " . CHG_VTBL . " (
				voter_id int(11) NOT NULL AUTO_INCREMENT,
				userid int(11) NOT NULL,
				vname varchar(255) NOT NULL,
				vemail varchar(255) NOT NULL,
				vcode varchar(255) NOT NULL,
				verified varchar(255) NOT NULL,
				created_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			    PRIMARY KEY (voter_id))";
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
	    }

    }
	
	/**
     *
     * Create folder to save pdf
     */
    public function chg_challenge_pdf() {
		$upload = wp_upload_dir();
		$upload_dir = $upload['basedir'];
		$upload_dir = $upload_dir . '/challenge';
		if (! is_dir($upload_dir)) {
		   mkdir( $upload_dir, 0700 );
		}
	}
	
	// Function to change email address
	function chg_sender_email( $original_email_address ) {
		return ' challengehq@earthtech.io';
	}
	 
	// Function to change sender name
	function chg_sender_name( $original_email_from ) {
		return 'EarthTech Challenge';
	}
	
	function chg_mail_content_type() {
		return "text/html";
	}

}

/*
* Starts our plugin class, easy!
*/
new CHG_Class();