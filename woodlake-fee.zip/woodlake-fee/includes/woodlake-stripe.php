<?php
/*
 * Stripe key settings function
 */
function stripe_settings() {
	if(is_admin()){
		global $wpdb;
		$tpbkey; $tpvtkey; $lpbkey; $lpvtkey; $stripekey;
		$stripedata = get_option('woodlake_stripekey');
		if(!empty($stripedata)) {
			$tpbkey = $stripedata['tpbkey'];
			$tpvtkey = $stripedata['tpvtkey'];
			$lpbkey = $stripedata['lpbkey'];
			$lpvtkey = $stripedata['lpvtkey'];
			$stripekey = $stripedata['stripekey'];
		}
	?>
		<style>
		.wl-stripe-setting-title {
			margin-top: 30px;
			font-size: 22px;
			line-height: 36px;
			font-weight: 700;
			letter-spacing:0.5px;
			background: linear-gradient(90deg, #F5286E 0%, #fc6d43 100%);
			box-shadow: 0 5px 15px 0 rgba(245,40,110,0.35);
			color: #fff;
			border-radius: 7px;
			margin-right: 50px;
			padding: 5px 30px;
		}
		.wl-stripe-setting-wrapper {
			margin-top: 20px;
			margin-right: 50px;
			text-align: left;
			box-shadow: 0 0 10px 0 rgba(0,0,0,.15);
			background: #fff;			
			border-radius: 7px;
			padding: 10px 30px;
		}
		.wl-key-table {
			display: flex;
			margin: 30px 0;
		}
		.wl-testkey-table, .wl-livekey-table {
			margin-right: 50px;
			box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1);
			border-radius: 7px;
			padding: 20px;
		}
		.wl-key-title {
			font-family: Montserrat;
			font-size: 20px;
			line-height: 28px;
			letter-spacing: .5px;
			font-weight: 700;
		}
		.wl-testkey-table .wl-key-title {
			color: #F5286E;
		}
		.wl-livekey-table .wl-key-title {
			color: #41C83E;
		}
		.wl-key-details, .wl-key-selector {
			margin-top: 10px;
			display: flex;
			align-items: center;
		}
		.wl-key-details label, .wl-key-selector label {
			width: 90px;
			font-size: 16px;
			line-height: 24px;
			text-align:left;
			font-weight: 500;
		}
		.wl-stripe-setting-wrapper input[type='text'] {
			height: 40px;
			background-color: #fff;
			border: 1px solid rgba(120, 129, 139, 0.25);
			border-radius: 7px;
			font-family: Lato;
			font-style: normal;
			font-weight: normal;
			font-size: 20px;
			line-height: 24px;
			text-align: justify;
			letter-spacing: 0.1px;
		}
		.wl-key-selector, .wl-stripe-setting-btn {
			margin: 30px 0;
		}
		.wl-key-selector select {
			width: 100px;
		}
		.wl-stripe-save-btn {
			width: 200px;
			height: 40px;
			font-family: Montserrat;
			font-style: normal;
			font-weight: bold;
			font-size: 16px;
			line-height: 19px;
			text-align: center;
			color: #FFFFFF;
			display: flex;
			justify-content: center;
			align-items: center;
			background: linear-gradient(270deg, #76E672 0%, #41C83E 100%);
			box-shadow: 0px 5px 15px rgba(68, 202, 65, 0.35);
			border-radius: 7px;
			cursor: pointer;
		}
		.wl-upd-sucs, .wl-upd-fail {
			font-size: 14px;
			margin-top: 10px;
			display: none;	
		}
		.wl-upd-sucs {
			color: green;			
		}
		.wl-upd-fail {
			color: red;
		}
		</style>
		<div class="wl-stripe-setting-title">Stripe Settings</div>
		<div class="wl-stripe-setting-wrapper">
			<div class="wl-key-table">
				<div class="wl-testkey-table">
					<div class="wl-key-title">Test keys</div>
					<div class="wl-key-details">
						<label>Public key</label>
						<input type='text' name='wl-stripe-test-pbkey' class="wl-stripe-test-pbkey" value='<?php if($tpbkey) { echo $tpbkey; } ?>' />
					</div>
					<div class="wl-key-details">
						<label>Private key</label>
						<input type='text' name='wl-stripe-test-pvtkey' class="wl-stripe-test-pvtkey" value='<?php if($tpbkey) { echo $tpvtkey; } ?>' />
					</div>
				</div>
				<div class="wl-livekey-table">
					<div class="wl-key-title">Live keys</div>
					<div class="wl-key-details">
						<label>Public key</label>
						<input type='text' name='wl-stripe-live-pbkey' class="wl-stripe-live-pbkey" value='<?php if($lpbkey) { echo $lpbkey; } ?>' />
					</div>
					<div class="wl-key-details">
						<label>Private key</label>
						<input type='text' name='wl-stripe-live-pvtkey' class="wl-stripe-live-pvtkey" value='<?php if($lpvtkey) { echo $lpvtkey; } ?>' />
					</div>
				</div>
			</div>
			<div class="wl-key-selector">
				<label>Select key</label>
				<select name="keytype" class="keytype">
					<option value="test" <?php if($stripekey == 'test') { echo 'selected'; } ?>>Test</option>
					<option value="live" <?php if($stripekey == 'live') { echo 'selected'; } ?>>Live</option>
				</select>
			</div>
			<div class="wl-stripe-setting-btn">
				<div class="wl-stripe-save-btn">Save settings</div>
				<div class="wl-upd-sucs">Settings updated succesfully.</div>
				<div class="wl-upd-fail">Failed to update settings.</div>
			</div>
		</div>
	<?php
	}
}

/*ajax function to insert stripe settings*/
function woodlake_insert_stripedata(){
	global $wpdb;
	
	$stripekey = array();
	$stripekey['tpbkey'] = $_POST['tpbkey'];
	$stripekey['tpvtkey'] = $_POST['tpvtkey'];
	$stripekey['lpbkey'] = $_POST['lpbkey'];
	$stripekey['lpvtkey'] = $_POST['lpvtkey'];
	$stripekey['stripekey'] = $_POST['stripekey'];
	
	$update = update_option('woodlake_stripekey', $stripekey);
	echo $update;
	die();
}
add_action( 'wp_ajax_insert_stripedata', 'woodlake_insert_stripedata' );
add_action( 'wp_ajax_nopriv_insert_stripedata', 'woodlake_insert_stripedata' );