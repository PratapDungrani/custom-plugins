<?php
/*
 * Experience form settings function
 */
function fee_table() {
	if(is_admin()){
		global $wpdb;
		
		$results = $wpdb->get_results( "SELECT * FROM " . WOODLAKE_FEE_TBL);
	?>
		<style>
		.fee-setting-title {
			margin-top: 30px;
			font-size: 22px;
			line-height: 36px;
			font-weight: 700;
			letter-spacing:0.5px;
			background: linear-gradient(90deg, #F5286E 0%, #fc6d43 100%);
			box-shadow: 0 5px 15px 0 rgba(245,40,110,0.35);
			color: #fff;
			border-radius: 7px;
			margin-right: 50px;
			padding: 5px 30px;
		}
		.fee-setting-wrapper {
			margin-top: 20px;
			margin-right: 50px;
			text-align: left;
			box-shadow: 0 0 10px 0 rgba(0,0,0,.15);
			background: #fff;			
			border-radius: 7px;
			padding: 30px;
		}
		.fee-setting-wrapper table {
			font-size: 16px;
			line-height: 56px;
			color: #1E1F22;
			font-weight: 500;
			padding: 10px 0;
		}
		.fee-setting-wrapper .fee-head {
			font-size: 16px;
			line-height: 20px;
			text-decoration: underline;
			padding-left: 2px;
		}
		.fee-setting-wrapper input[type="text"] {
			height: 40px;
			width: 260px;
		}
		.add-remove-field {
			display: flex;
			align-items: center;
		}
		.add-remove-field .dashicons.dashicons-insert {
			background-image: linear-gradient(90deg, #F5286E 0%, #FC6D43 100%);
			-webkit-text-fill-color: transparent;
			-webkit-background-clip: text;
			margin-right: 5px;
		}
		.add-remove-field .dashicons {
			cursor: pointer;
		}
		.save-fee {
			color: green;
			cursor: pointer;
		}
		.delete-fee {
			color: red;
			cursor: pointer;
			display: none;
		}
		.fee-upd-sucs, .fee-upd-fail, .fee-upd-sucs-del, .fee-upd-fail-del {
			font-size: 14px;
			margin-top: 10px;
			display: none;	
		}
		.fee-upd-sucs, .fee-upd-sucs-del {
			color: green;	
		}
		.fee-upd-fail, .fee-upd-fail-del {
			color: red;
		}
		</style>
		<div class="fee-setting-title">Woodlake Fee Table</div>
		<div class="fee-setting-wrapper">
			<table class="fee-table">
				<thead>
					<tr>
						<th><div class="fee-head">Age Group</div></th>
						<th><div class="fee-head">Monthly</div></th>
						<th><div class="fee-head">Full Summer</div></th>
						<th><div class="fee-head">Guest</div></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
				<?php
				if(!empty($results)) {
					foreach($results as $result) {
						$id = $result->id;
						$age_group = $result->age_group;
						$monthly = $result->monthly;
						$full_summer = $result->full_summer;
						$guest = $result->guest;
				?>
						<tr>
							<td>
								<input type='text' name='age_group' class='agegroup' placeholder='Enter group name' value="<?php if($age_group) { echo $age_group; } ?>" />
								<input type='hidden' name='groupid' class='groupid' value="<?php if($id) { echo $id; } ?>" />
							</td>
							<td><input type='text' name='monthly' class='monthly' placeholder='Enter monthly fee' value="<?php if($monthly) { echo $monthly; } ?>" /></td>
							<td><input type='text' name='full_summer' class='fullsummer' placeholder='Enter full summer fee' value="<?php if($full_summer) { echo $full_summer; } ?>" /></td>
							<td><input type='text' name='guest' class='guest' placeholder='Enter guest fee' value="<?php if($guest) { echo $guest; } ?>" /></td>
							<td><div class="add-remove-field"><span class="dashicons dashicons-insert"></span><span class="dashicons dashicons-remove"></span></div></td>
							<td><u class="save-fee">Update<u></td>
						</tr>
						<?php
					}
				} else { ?>				
					<tr>
						<td>
							<input type='text' name='age_group' class='agegroup' placeholder='Enter group name' value="" />
							<input type='hidden' name='groupid' class='groupid' value="" />
						</td>
						<td><input type='text' name='monthly' class='monthly' placeholder='Enter monthly fee' value="" /></td>
						<td><input type='text' name='full_summer' class='fullsummer' placeholder='Enter full summer fee' value="" /></td>
						<td><input type='text' name='guest' class='guest' placeholder='Enter guest fee' value="" /></td>
						<td><div class="add-remove-field"><span class="dashicons dashicons-insert"></span><span class="dashicons dashicons-remove"></span></div></td>
						<td><u class="save-fee">Save</u></td>
					</tr>
				<?php 
				}
				?>
				</tbody>
			</table>
			<div class="fee-upd-sucs">Data updated succesfully.</div>
			<div class="fee-upd-fail">Failed to update data.</div>
			<div class="fee-upd-sucs-del">Data deleted succesfully.</div>
			<div class="fee-upd-fail-del">Failed to delete data.</div>
		</div>
	<?php
	}
}


/*ajax function to insert fee field*/
function insert_fee_field(){
	?>
	<tr>
		<td>
			<input type='text' name='age_group' class='agegroup' placeholder='Enter group name' value="" />
			<input type='hidden' name='groupid' class='groupid' value="" />
		</td>
		<td><input type='text' name='monthly' class='monthly' placeholder='Enter monthly fee' value="" /></td>
		<td><input type='text' name='full_summer' class='fullsummer' placeholder='Enter full summer fee' value="" /></td>
		<td><input type='text' name='guest' class='guest' placeholder='Enter guest fee' value="" /></td>
		<td><div class="add-remove-field"><span class="dashicons dashicons-insert"></span><span class="dashicons dashicons-remove"></span></div></td>
		<td><u class="save-fee">Save</u></td>
	</tr>
	<?php
	die();
}
add_action( 'wp_ajax_add_fee_field', 'insert_fee_field' );
add_action( 'wp_ajax_nopriv_add_fee_field', 'insert_fee_field' );

/*ajax function to insert fee data*/
function insert_fee_data(){
	global $wpdb;
	$table  = WOODLAKE_FEE_TBL;
	$format = null; $where_format = null;
	
	$fee_data = $_POST['fee_data'];
	$fee_id = $fee_data['groupid'];
	unset($fee_data['groupid']);
	
	if($fee_id) {
		$wpdb->update($table, $fee_data, array('id' => $fee_id), $format, $where_format);
		if($wpdb->show_errors == '' && $wpdb->rows_affected > 0) {
			echo 'true';
		}
	} else {
		$wpdb->insert($table, $fee_data, $format);
		if($wpdb->show_errors == '' && $wpdb->rows_affected > 0) {
			echo 'true';
		}
	}
	die();
}
add_action( 'wp_ajax_add_fee_data', 'insert_fee_data' );
add_action( 'wp_ajax_nopriv_add_fee_data', 'insert_fee_data' );

/*ajax function to delete fee data*/
function remove_fee_data(){
	global $wpdb;
	$table  = WOODLAKE_FEE_TBL;
	$where_format = null;
	
	$fee_id = $_POST['id'];
	
	if($fee_id) {
		$wpdb->delete( $table, array('id' => $fee_id), $where_format );
		if($wpdb->show_errors == '' && $wpdb->rows_affected > 0) {
			echo 'true';
		}
	}
	die();
}
add_action( 'wp_ajax_delete_fee_data', 'remove_fee_data' );
add_action( 'wp_ajax_nopriv_delete_fee_data', 'remove_fee_data' );