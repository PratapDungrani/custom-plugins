<?php
// Register Custom Post Type for JOJ options
function joj_options_function() {

	$labels = array(
		'name'                  => _x( 'Options', 'Post Type General Name', 'JOJ_TEXTDOMAIN' ),
		'singular_name'         => _x( 'Option', 'Post Type Singular Name', 'JOJ_TEXTDOMAIN' ),
		'menu_name'             => __( 'Options', 'JOJ_TEXTDOMAIN' ),
		'name_admin_bar'        => __( 'Option', 'JOJ_TEXTDOMAIN' ),
		'archives'              => __( 'Item Archives', 'JOJ_TEXTDOMAIN' ),
		'attributes'            => __( 'Item Attributes', 'JOJ_TEXTDOMAIN' ),
		'parent_item_colon'     => __( 'Parent Item:', 'JOJ_TEXTDOMAIN' ),
		'all_items'             => __( 'Options', 'JOJ_TEXTDOMAIN' ),
		'add_new_item'          => __( 'Add New Item', 'JOJ_TEXTDOMAIN' ),
		'add_new'               => __( 'Add New', 'JOJ_TEXTDOMAIN' ),
		'new_item'              => __( 'New Item', 'JOJ_TEXTDOMAIN' ),
		'edit_item'             => __( 'Edit Item', 'JOJ_TEXTDOMAIN' ),
		'update_item'           => __( 'Update Item', 'JOJ_TEXTDOMAIN' ),
		'view_item'             => __( 'View Item', 'JOJ_TEXTDOMAIN' ),
		'view_items'            => __( 'View Items', 'JOJ_TEXTDOMAIN' ),
		'search_items'          => __( 'Search Item', 'JOJ_TEXTDOMAIN' ),
		'not_found'             => __( 'Not found', 'JOJ_TEXTDOMAIN' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'JOJ_TEXTDOMAIN' ),
		'featured_image'        => __( 'Featured Image', 'JOJ_TEXTDOMAIN' ),
		'set_featured_image'    => __( 'Set featured image', 'JOJ_TEXTDOMAIN' ),
		'remove_featured_image' => __( 'Remove featured image', 'JOJ_TEXTDOMAIN' ),
		'use_featured_image'    => __( 'Use as featured image', 'JOJ_TEXTDOMAIN' ),
		'insert_into_item'      => __( 'Insert into item', 'JOJ_TEXTDOMAIN' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'JOJ_TEXTDOMAIN' ),
		'items_list'            => __( 'Items list', 'JOJ_TEXTDOMAIN' ),
		'items_list_navigation' => __( 'Items list navigation', 'JOJ_TEXTDOMAIN' ),
		'filter_items_list'     => __( 'Filter items list', 'JOJ_TEXTDOMAIN' ),
	);
	$args = array(
		'label'                 => __( 'Option', 'JOJ_TEXTDOMAIN' ),
		'description'           => __( 'Post Type Description', 'JOJ_TEXTDOMAIN' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => 'joj_letter',
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'joj_option', $args );
	
	$label = array(
		'name'                  => _x( 'Representatives', 'Post Type General Name', 'JOJ_TEXTDOMAIN' ),
		'singular_name'         => _x( 'Representative', 'Post Type Singular Name', 'JOJ_TEXTDOMAIN' ),
		'menu_name'             => __( 'Representatives', 'JOJ_TEXTDOMAIN' ),
		'name_admin_bar'        => __( 'Representative', 'JOJ_TEXTDOMAIN' ),
		'archives'              => __( 'Item Archives', 'JOJ_TEXTDOMAIN' ),
		'attributes'            => __( 'Item Attributes', 'JOJ_TEXTDOMAIN' ),
		'parent_item_colon'     => __( 'Parent Item:', 'JOJ_TEXTDOMAIN' ),
		'all_items'             => __( 'Representatives', 'JOJ_TEXTDOMAIN' ),
		'add_new_item'          => __( 'Add New Representative', 'JOJ_TEXTDOMAIN' ),
		'add_new'               => __( 'Add New', 'JOJ_TEXTDOMAIN' ),
		'new_item'              => __( 'New Item', 'JOJ_TEXTDOMAIN' ),
		'edit_item'             => __( 'Edit Item', 'JOJ_TEXTDOMAIN' ),
		'update_item'           => __( 'Update Item', 'JOJ_TEXTDOMAIN' ),
		'view_item'             => __( 'View Item', 'JOJ_TEXTDOMAIN' ),
		'view_items'            => __( 'View Items', 'JOJ_TEXTDOMAIN' ),
		'search_items'          => __( 'Search Item', 'JOJ_TEXTDOMAIN' ),
		'not_found'             => __( 'Not found', 'JOJ_TEXTDOMAIN' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'JOJ_TEXTDOMAIN' ),
		'featured_image'        => __( 'Featured Image', 'JOJ_TEXTDOMAIN' ),
		'set_featured_image'    => __( 'Set featured image', 'JOJ_TEXTDOMAIN' ),
		'remove_featured_image' => __( 'Remove featured image', 'JOJ_TEXTDOMAIN' ),
		'use_featured_image'    => __( 'Use as featured image', 'JOJ_TEXTDOMAIN' ),
		'insert_into_item'      => __( 'Insert into item', 'JOJ_TEXTDOMAIN' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'JOJ_TEXTDOMAIN' ),
		'items_list'            => __( 'Items list', 'JOJ_TEXTDOMAIN' ),
		'items_list_navigation' => __( 'Items list navigation', 'JOJ_TEXTDOMAIN' ),
		'filter_items_list'     => __( 'Filter items list', 'JOJ_TEXTDOMAIN' ),
	);
	$arg = array(
		'label'                 => __( 'Representative', 'JOJ_TEXTDOMAIN' ),
		'description'           => __( 'Representative Description', 'JOJ_TEXTDOMAIN' ),
		'labels'                => $label,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => 'joj_letter',
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'joj_representative', $arg );

}
add_action( 'init', 'joj_options_function', 0 );

/* Add phone script meta in custom post type by Pratap */
function add_custom_meta_box()
{
    add_meta_box("phonescript-meta-box", "Phone Script", "phonescript_meta_box_markup", "joj_option", "normal", "default", null);
}
add_action("add_meta_boxes", "add_custom_meta_box");

/* Display data in meta box by Pratap */
function phonescript_meta_box_markup() {
	global $wpdb, $post, $pagenow;
	$chk_phnscript;
	
	if ($pagenow=='post-new.php' && isset($_GET['post_type']) && $_GET['post_type']=='joj_option')  {
		$chk_phnscript = '';
	} else if ($pagenow=='post.php' && $_GET['action'] == 'edit')   {
		$chk_phnscript = get_post_meta(get_the_ID(), 'phone_script', true);
	}	
	?>
	<div class="script-container">
		<textarea name="phone_script" class="script_area"><?php echo $chk_phnscript; ?></textarea>
	</div>
	<style>
	.script-container {
		min-height: 200px;
	}
	.script_area {
		width: 50%;
		min-height: 200px;
		margin: 10px;
	}
	</style>
	<?php
}

/* save/update meta of post_type=joj_option  by Pratap */
function save_metabox( $post_id, $post ) {

	// Add nonce for security and authentication.
	$phone_script = isset( $_POST['phone_script'] ) ? $_POST['phone_script'] : '';

	// Check if the user has permissions to save data.
	if ( ! current_user_can( 'edit_post', $post_id ) )
	return;

	// Check if it's not an autosave.
	if ( wp_is_post_autosave( $post_id ) )
	return;

	// Check if it's not a revision.
	if ( wp_is_post_revision( $post_id ) )
	return;

	update_post_meta( $post_id, 'phone_script', $phone_script );
}
add_action( 'save_post', 'save_metabox', 10, 2);