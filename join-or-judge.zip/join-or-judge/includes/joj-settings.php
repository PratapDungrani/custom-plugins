<?php
/*
 * JOJ settings function
 */
function joj_settings() {
	if ( isset( $_POST['submit_setting'] ) ) {
		$joj_suc_image = !empty($_POST['image_attachment_id']) ? $_POST['image_attachment_id'] : '';
		$joj_suc_message = !empty($_POST['joj_success_message']) ? $_POST['joj_success_message'] : '';
		$joj_mailing_inst = !empty($_POST['joj_mailing_inst']) ? $_POST['joj_mailing_inst'] : '';
		update_option( 'joj_suc_image', absint($joj_suc_image));
		update_option( 'joj_suc_message', $joj_suc_message );
		update_option( 'joj_mailing_inst', $joj_mailing_inst );
		$class   = 'updated';
		$message = "Settings saved successfully.";
	}
	$joj_suc_image = get_option('joj_suc_image');
	$joj_suc_message = get_option('joj_suc_message');
	$joj_mailing_inst = get_option('joj_mailing_inst');
	
	wp_enqueue_media();
	?>
	<div class="wrap">
	<?php
		if ( ! empty($class) && ! empty($message) ) {
		?>
			<div class="<?php echo $class; ?> notice notice-success is-dismissible">
				<p><?php _e($message, JOJ_TEXTDOMAIN);?></p>
			</div>
		<?php
		}
		?>
		<h1 class="wp-heading-inline" style="margin-bottom:25px;"><?php _e('Settings', JOJ_TEXTDOMAIN); ?></h1>
		<div id='col-container'>
			<form class="wsn-form" method="POST" action="<?php echo admin_url('admin.php'). "?" . $_SERVER['QUERY_STRING']; ?>">
				<div class="wsn-box-border">
					<table class="wsn-setting-table form-table">
						<tr>
							<th><?php _e('Select Image:', JOJ_TEXTDOMAIN); ?></th>
							<td>
								<div>
									<img id='image-preview' src='<?php echo wp_get_attachment_url( $joj_suc_image ); ?>' height='100'>
								</div><br>
								<input id="upload_image_button" type="button" class="button" value="<?php _e( 'Upload image' ); ?>" />
								<input type='hidden' name='image_attachment_id' id='image_attachment_id' value='<?php if(!empty($joj_suc_image)) echo $joj_suc_image; ?>'>
							</td>
						</tr>
						<tr>
							<th><?php _e('Success Message:', JOJ_TEXTDOMAIN); ?></th>
							<td>
								<textarea  id="joj_success_message" name="joj_success_message"/><?php if(!empty($joj_suc_message)) echo $joj_suc_message; ?></textarea>
							</td>
						</tr>
						<tr>
							<th><?php _e('Mailing Instruction:', JOJ_TEXTDOMAIN); ?></th>
							<td>
								<textarea  id="joj_mailing_inst" name="joj_mailing_inst"/><?php if(!empty($joj_mailing_inst)) echo $joj_mailing_inst; ?></textarea>
							</td>
						</tr>
					</table>
					<p class="submit">
						<input id="submit" class="button button-primary" type="submit" value="<?php _e('Save Changes', JOJ_TEXTDOMAIN); ?>" name="submit_setting">
					</p>
				</div>
			</form>
		</div>
	</div>
	<?php
}

/*image selector by Pratap*/
function media_selector_print_scripts() {
	if(isset($_GET['page']) && $_GET['page'] == 'joj_settings') {
	$my_saved_attachment_post_id = get_option( 'joj_suc_image', 0 );
	?><script type='text/javascript'>
		jQuery( document ).ready( function( $ ) {
			// Uploading files
			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this
			jQuery('#upload_image_button').on('click', function( event ){
				event.preventDefault();
				// If the media frame already exists, reopen it.
				if ( file_frame ) {
					// Set the post ID to what we want
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
					// Open frame
					file_frame.open();
					return;
				} else {
					// Set the wp.media post id so the uploader grabs the ID we want when initialised
					wp.media.model.settings.post.id = set_to_post_id;
				}
				// Create the media frame.
				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false	// Set to true to allow multiple files to be selected
				});
				// When an image is selected, run a callback.
				file_frame.on( 'select', function() {
					// We set multiple to false so only get one image from the uploader
					attachment = file_frame.state().get('selection').first().toJSON();
					// Do something with attachment.id and/or attachment.url here
					$( '#image-preview' ).attr( 'src', attachment.url );
					$( '#image_attachment_id' ).val( attachment.id );
					// Restore the main post ID
					wp.media.model.settings.post.id = wp_media_post_id;
				});
					// Finally, open the modal
					file_frame.open();
			});
			// Restore the main ID when the add media button is pressed
			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});
		});
	</script>
	<?php
	}
}
add_action( 'admin_footer', 'media_selector_print_scripts' );

/*
 * JOJ letter export
 */
function joj_letter_export() {
		if (isset($_POST["joj-export"])) {
			$exportCSV = new joj_export_table_to_csv(JOJ_LETTER_TBL,',','report');
			$csv = $exportCSV->generate_csv();
		}
}
add_action( 'admin_init', 'joj_letter_export' );

/*
 * JOJ letter list function
 */
function joj_letter() {
	global $wpdb;
	?>
	<div class='wrap'>
		<h1 class="wp-heading-inline" style="margin-bottom:25px;"><?php _e('Join or Judge', JOJ_TEXTDOMAIN) ?></h1>
		<form method="post" action="<?php echo admin_url('admin.php'). "?" . $_SERVER['QUERY_STRING']; ?>">
			<input type="submit" name="joj-export" class="page-title-action" value="<?php esc_html_e('Export to CSV', JOJ_TEXTDOMAIN) ?>" />
		</form>
		<hr class="wp-header-end">
		<div id='col-container'>
			<table class="widefat post fixed striped wsn-table" cellspacing="0">
				<thead>
					<tr>
						<th class="is-seriel"><?php _e('No.', JOJ_TEXTDOMAIN); ?></th>
						<th class="is-fname"><?php _e('First Name', JOJ_TEXTDOMAIN); ?></th>
						<th class="is-lname"><?php _e('Last Name', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Email', JOJ_TEXTDOMAIN); ?></th>
						<th class="is-add"><?php _e('Address', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Congressman', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Reason', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Date Created', JOJ_TEXTDOMAIN); ?></th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th><?php _e('No.', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('First Name', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Last Name', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Email', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Address', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Congressman', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Reason', JOJ_TEXTDOMAIN); ?></th>
						<th><?php _e('Date Created', JOJ_TEXTDOMAIN); ?></th>
					</tr>
				</tfoot>
				<tbody>
					<?php
						$sel_sub = "SELECT * from " . JOJ_LETTER_TBL . " ORDER BY id DESC";
						$get_data     = $wpdb->get_results($sel_sub);
						if ( $get_data ) {
							$srno = 1;
							foreach ( $get_data as $data ) {
							?>
							<tr>
								<td><?php echo $srno;?></td>
								<td scope="col"><?php echo $data->fname;?></td>
								<td scope="col"><?php echo $data->lname;?></td>
								<td scope="col"><?php echo $data->email;?></td>
								<td scope="col"><?php echo $data->address;?></td>
								<td scope="col"><?php echo $data->congressman;?></td>
								<td scope="col"><?php echo $data->reason;?></td>
								<td scope="col"><?php echo $data->created_date;?></td>

							</tr>
						<?php $srno++;
							}
						} else {
							echo '<tr><td colspan="4">'. esc_html('No record available', JOJ_TEXTDOMAIN) .'</td></tr>';
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
}