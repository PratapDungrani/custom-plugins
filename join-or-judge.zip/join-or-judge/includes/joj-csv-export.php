<?php
/*
 * JOJ export table class
 */
class joj_export_table_to_csv{

	private $db;
	private $table_name;
	private $separator;

	function __construct($table_name, $sep, $filename){

		global $wpdb;
		$this->db = $wpdb;
		$this->table_name = $table_name;
		$this->separator = $sep;

		$generatedDate = date('d-m-Y His');
		$csvFile = $this->generate_csv();

		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private", false);
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename=\"" . $filename . " " . $generatedDate . ".csv\";" );
		header("Content-Transfer-Encoding: binary");

		echo $csvFile;
		exit;

	}

	function generate_csv(){

		$csv_output = '';
		$table = $this->table_name;

		$result = $this->db->get_results("SHOW COLUMNS FROM " . $table . "");

		if (count($result) > 0) {

			foreach($result as $row) {
				//var_dump($row->Field);
				if($row->Field == 'fname' || $row->Field == 'lname' || $row->Field == 'email' || $row->Field == 'address' || $row->Field == 'congressman' || $row->Field == 'reason' || $row->Field == 'created_date')
					$csv_output = $csv_output . $row->Field . $this->separator;
			}
			$csv_output = substr($csv_output, 0, -1);

		}
		$csv_output .= "\r\n";

		$values = $this->db->get_results("SELECT * FROM " . $table . "");

		foreach ($values as $rowr) {
			$fields[0]=$rowr->fname;
			$fields[1]=$rowr->lname;
			$fields[2]=$rowr->email;
			$fields[3]=$rowr->address;
			$fields[4]=$rowr->congressman;
			$fields[5]=$rowr->reason;
			$fields[6]=$rowr->created_date;
			
			$csv_output .= implode($this->separator, $fields);
			$csv_output .= "\r\n";
		}

		return $csv_output;

	}
}