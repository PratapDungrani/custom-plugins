<?php
/**
 * Register the form shortcode by Pratap
 *
 */
function joj_letter_shortcode()
{
	ob_start();
	?>
	<form method="post">
		<div class="is-supercontainer">
			<!--User detail form-->
			<div class="user-form is-form">
				<div class="is-container1">
					<!--error-->
					<p class="info-error"><?php esc_html_e('Please enter all the details', JOJ_TEXTDOMAIN); ?></p>
					<p class="email-error"><?php esc_html_e('Please enter valid email', JOJ_TEXTDOMAIN); ?></p>
					<p class="email-exist"><?php esc_html_e('You had already sent an email', JOJ_TEXTDOMAIN); ?></p>
					<p class="not-address"><?php esc_html_e('No Representative found for this address', JOJ_TEXTDOMAIN); ?></p>
					<!--User Details-->
					<div class="is-fullname">
						<label><?php esc_html_e('Your Name', JOJ_TEXTDOMAIN); ?></label>
						<div class="is-name">
							<div class="isname">
								<input type="text" name="isfname" class="isfname">
								<span class="is-disc"><?php esc_html_e('First', JOJ_TEXTDOMAIN); ?></span>
							</div>
							<div class="isname">
								<input type="text" name="islname" class="islname">
								<span class="is-disc"><?php esc_html_e('Last', JOJ_TEXTDOMAIN); ?></span>
							</div>
						</div>
					</div>
					<div class="is-email">
						<label><?php esc_html_e('Your Email', JOJ_TEXTDOMAIN); ?></label>
						<div><input type="email" name="isemail" placeholder="email@domain.com" class="isemail"></div>
						<span class="is-disc"><?php esc_html_e('Enter email where you want to receive letter & instructions', JOJ_TEXTDOMAIN); ?></span>
					</div>
					<div class="is-address">
						<label><?php esc_html_e('Your Address', JOJ_TEXTDOMAIN); ?></label>
						<div><input type="text" name="isaddress" placeholder="123 Main Street, Houston, TX 77070" class="isaddress"></div>
						<span class="is-disc"><?php esc_html_e('Enter your full address here', JOJ_TEXTDOMAIN); ?></span>
					</div>
					<div class="is-info"><?php esc_html_e('We will use the information entered above to identify your elected representative', JOJ_TEXTDOMAIN); ?></div>
					<div class="is-sumbit submit-info"><?php esc_html_e('FIND MY REPRESENTATIVE', JOJ_TEXTDOMAIN); ?></div>
				</div>
			</div>
			
			<!--Representative detail and reason form-->
			<div class="user-form is-letter">
				<div class="is-container2">
					<p class="reason-error"><?php esc_html_e('Please select reason', JOJ_TEXTDOMAIN); ?></p>
					<p class="database-error"><?php esc_html_e('Unable to send Letter. Please try after sometime.', JOJ_TEXTDOMAIN); ?></p>
					<div class="is-representative">
						<div class="is-rep-img"><img src="<?php echo JOJ_URL.'assets/images/noimage.png'; ?>" alt="" /></div>
						<div class="is-rep-info">
							<div class="is-rep-name">
								<div class="is-repname"></div>
								<div class="is-party"></div>
							</div>
							<div class="is-rep-place">
								<div class="is-dist"><?php esc_html_e('Congressional District', JOJ_TEXTDOMAIN); ?></div>
								<div class="is-state"></div>
							</div>
						</div>
					</div>
					<div class="is-repinfo"><?php esc_html_e('This is the representative to whom your letter will be addressed. We will also include mailing address & instructions in your email.', JOJ_TEXTDOMAIN); ?></div>
					<div class="is-reason">
						<label><?php esc_html_e('Reason for your suppport', JOJ_TEXTDOMAIN); ?></label>
						<div class="is-reason-option"><?php esc_html_e('Select the main reason you support this cannabis legislation. This will determine the content of your letter.', JOJ_TEXTDOMAIN); ?></div>
						<div class="is-option">
						<?php
						$args = array( 
							'post_type' => 'joj_option',
							'post_status' => 'publish',
							'orderby'        => 'ID',
							'order'          => 'DESC',
							'posts_per_page' => -1,
						);
						
						$posts = get_posts($args);						
						foreach($posts as $post){
						?>
							<span><input type="radio" name="reason" value="<?php echo $post->ID; ?>"><?php echo $post->post_title; ?></span>
						<?php
							}
						?>
						</div>
					</div>
					<div class="is-sumbit submit-letter"><?php esc_html_e('WRITE MY LETTER', JOJ_TEXTDOMAIN); ?></div>
				</div>
			</div>
			
			<!-- thank you message-->
			<div class="user-form is-message">
				<div class="is-container3">
					<div class="is-success">
						<div class="is-success-txt1"><?php esc_html_e('Success!', JOJ_TEXTDOMAIN); ?></div>
						<div class="is-success-txt2"><?php esc_html_e('Your letter is on its way', JOJ_TEXTDOMAIN); ?></div>
					</div>
					<?php
					$suc_image_id = get_option('joj_suc_image');
					$src = wp_get_attachment_url($suc_image_id);
					if($src == '') {
						$suc_image = JOJ_URL.'assets/images/suc_img.png';
					} else {
						$suc_image = $src;
					}
					$suc_msg = get_option('joj_suc_message');
					if($suc_msg != '') {
						$suc_message = $suc_msg;
					} else {
						$suc_message = "Thank you for your support";
					}
					?>
					<div class="is-suc-img"><img src="<?php echo $suc_image; ?>" alt="" /></div>
					<div class="is-success-msg"><?php echo $suc_message; ?></div>
				</div>
			</div>
		</div>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'joinorjudge-letter-form', 'joj_letter_shortcode' );

/*check if email exist and get representative data from api by Pratap*/
function joj_validate_email() {
	global $wpdb;
	$email = $_POST["email"];
	$address = $_POST["address"];
	$find = array(",",".");
	$replace = array(" ");
	$address = str_replace($find,$replace,$address);
	$address = rtrim(ltrim($address));
	
	$result = $wpdb->get_results("SELECT * FROM " .JOJ_LETTER_TBL. " WHERE email = '".$email."'");
	
	if(!empty($result)) {
		echo "true";
	} else {
		
		$url = 'https://content.googleapis.com/civicinfo/v2/representatives?address='.$address.'&includeOffices=true&levels=country&roles=legislatorLowerBody&key=AIzaSyBDay0XkvFYRPcsBfsGhg07nTOy6HJDKhY';
		$response = wp_remote_get( $url );
		$response = json_decode(json_encode($response), true);
		$rst = array();
		$can_id;

		$body = $response['body'];
		$body = json_decode($body);
		
		$officials = $body->officials;
		$can_name = $officials[0]->name;
		$can_party = $officials[0]->party;
		$can_phon = $officials[0]->phones;
		$can_phone = $can_phon[0];
		$can_photo = $officials[0]->photoUrl;
		
		if($can_photo == '') {
			$rst = $wpdb->get_results("SELECT ID FROM {$wpdb->prefix}posts WHERE post_type = 'joj_representative' AND post_title LIKE '%".$can_name."%'");
			if(!empty($rst)) {
				$can_id = $rst[0]->ID;
				$can_photo = get_the_post_thumbnail_url($can_id, 'post-thumbnail');
			}
		}
		
		$divisions = $body->divisions;
		$can_district = '';
		foreach($divisions as $division) {
			$can_district = $division->name;
		}
		
		$myarray = array('can_name'=>$can_name, 'can_party'=>$can_party, 'can_photo'=>$can_photo, 'can_district'=>$can_district, 'can_phone'=>$can_phone);
		echo json_encode($myarray);
		
	}
	die();
}
add_action( 'wp_ajax_joj_validate_email', 'joj_validate_email' );
add_action( 'wp_ajax_nopriv_joj_validate_email', 'joj_validate_email' );

/*insert user data into database, create pdf, send mail with pdf by Pratap*/
function joj_insert_data() {
	global $wpdb;
	$content; $pdfname; $pdfnam;
	$fname = $_POST["fname"];
	$lname = $_POST["lname"];
	$email = $_POST["email"];
	
	$address = $_POST["address"];
	$find = array(",",".");
	$replace = array(" ");
	$address = str_replace($find,$replace,$address);
	$address = rtrim(ltrim($address));
	
	$can_name = $_POST["can_name"];
	$reason_id = $_POST["reason_id"];
	$submit_date = date_i18n( 'F j, Y' );
	
	$result = get_post($reason_id);
	$reason = $result->post_title;
	$description = apply_filters('the_content', $result->post_content);
	$parts = preg_split('/\r\n|\r|\n/', $description);
	$count = count($parts);
	for($i=0; $i<$count; $i++) {
        $content .='<div style="margin-bottom: 5px;">'.$parts[$i].'</div>'; // non-existent additions does not concatenate
    }
	
	$insert = $wpdb->query("INSERT INTO " . JOJ_LETTER_TBL . " (fname,lname,email,address,congressman,reason) VALUES ('".$fname."','".$lname."','".$email."','".$address."','".$can_name."','".$reason."')");
	
	if($insert == 1) {
		$url = 'https://content.googleapis.com/civicinfo/v2/representatives?address='.$address.'&includeOffices=true&levels=country&roles=legislatorLowerBody&key=AIzaSyBDay0XkvFYRPcsBfsGhg07nTOy6HJDKhY';
		$response = wp_remote_get( $url );
		$response = json_decode(json_encode($response), true);

		$body = $response['body'];
		$body = json_decode($body);
		
		//user address
		$user_address = $body->normalizedInput;
		$user_street = $user_address->line1;
		$user_city = $user_address->city;
		$user_state = $user_address->state;
		$user_zip = $user_address->zip;
		
		//representative info
		$officials = $body->officials;
		$can_phon = $officials[0]->phones;
		$can_phone = $can_phon[0];
		$can_photo = $officials[0]->photoUrl;
		$can_add = $officials[0]->address;
		$can_address = $can_add[0];
		$rep_street = $can_address->line1;
		$rep_city = $can_address->city;
		$rep_state = $can_address->state;
		$rep_zip = $can_address->zip;
		
		$joj_mailing_inst = get_option('joj_mailing_inst');
		$chk_phnscript = get_post_meta($reason_id, 'phone_script', true);
		
		try {
			require_once JOJ_DIR.'/vendor/autoload.php';
			$letter = '<div style="padding: 30px; font-family: Palanquin Dark, sans-serif; font-size: 16px;">
						<div style="text-align: right;">
							<div style="font-size: 18px;"><span>'.$fname.'</span> <span>'.$lname.'</span></div>
							<div style="margin-top:5px; font-size: 15px;">
								<div>'.$user_street.'</div>
								<div>'.$user_city.', '.$user_state.' '.$user_zip.'</div>
							</div>
							<div>'.$email.'</div>
						</div>
						<div>
							<div>'.$submit_date.'</div>
							<div style="margin: 25px 0;">
								<div style="font-size: 18px;">'.$can_name.'</div>
								<div style="margin-top:5px; font-size: 15px;">
									<div>'.$rep_street.'</div>
									<div>'.$rep_city.', '.$rep_state.' '.$rep_zip.'</div>
								</div>
							</div>
						</div>
						<div>
							<div style="margin: 10px 0 5px 0;">Dear '.$can_name.'</div>
							<div style="text-align: justify;">'.$content.'</div>
							<div style="margin-top: 20px;">Sincerely,</div>
							<div style="margin-top: 20px;"><span>'.$fname.'</span> <span>'.$lname.'</span></div>
						</div>
					</div>';
			
			$phnscript = '<div style="padding: 30px; font-family: Palanquin Dark, sans-serif; font-size: 16px;">
					<div>
						<div style="text-align:center;"><h2>Instructions for mailing your letter</h2></div>
						<div style="text-align: justify;">'.$joj_mailing_inst.'</div>
					</div>
					<div style="margin-top: 100px;">
						<div style="text-align:center;"><h2>Phone Script</h2></div>
						<div>
							<div><span><b>Your Representative:</b> </span><span>'.$can_name.'</span></div>
							<div><span><b>Office phone:</b> </span><span>'.$can_phone.'</span></div>
						</div>
						<div style="text-align: justify;">
							<div style="margin: 15px 0;">Based on your selected reason for supporting cannabis reform, we’ve included a handy phone
script you can use when calling representative:</div>
							<div>'.$chk_phnscript.'</div>
						</div>
					</div>
				</div>';
				
				/*For letter*/
				$mpdf = new \Mpdf\Mpdf();
				$mpdf->WriteHTML($letter);
				
				//save the file put which location you need folder/filname
				$pdfname = $fname." ".$lname;
				$mpdf->Output(JOJ_DIR."/pdf/".$pdfname.".pdf", 'F');
				
				
				/*For phone script*/
				$mpdf = new \Mpdf\Mpdf();
				$mpdf->WriteHTML($phnscript);
				
				//save the file put which location you need folder/filname
				$pdfnam = $fname." ".$lname."phonescript";
				$mpdf->Output(JOJ_DIR."/pdf/".$pdfnam.".pdf", 'F');
				
				
		} catch(\Mpdf\MpdfException $e) {
			echo $e->getMessage();
		}
	
		//user posted variables
		$admin_email = "test@gmail.com";
		$message = "Hello, I am testing";
		$attachments = array(JOJ_DIR."/pdf/".$pdfname.".pdf", JOJ_DIR."/pdf/".$pdfnam.".pdf");

		//php mailer variables
		$to = $email;
		$subject = "Some text in subject...";
		$headers = 'From: '. $admin_email . "\r\n" .
				   'Reply-To: ' . $admin_email . "\r\n";


		//Here put your Validation and send mail
		$sent = wp_mail($to, $subject, strip_tags($message), $headers, $attachments);
		/*if($sent) {
			echo "mail sent successfully";
		} else  {
			echo "mail sent failed";
		}*/
	}
	echo $insert;
	
	die();
}
add_action( 'wp_ajax_joj_insert_data', 'joj_insert_data' );
add_action( 'wp_ajax_nopriv_joj_insert_data', 'joj_insert_data' );

/*for testing pdf by Pratap*/
function joj_send_letter() {
	$content = '';
	$result = get_post(21);
	$reason = $result->post_title;
	$joj_mailing_inst = get_option('joj_mailing_inst');
	$chk_phnscript = get_post_meta(21, 'phone_script', true);
	
	try {
		require_once JOJ_DIR.'/vendor/autoload.php';
		$html = '<div style="padding: 30px; font-family: Palanquin Dark, sans-serif; font-size: 16px;">
					<div>
						<div style="text-align:center;"><h2>Instructions for mailing your letter</h2></div>
						<div style="text-align: justify;">'.$joj_mailing_inst.'</div>
					</div>
					<div style="margin-top: 100px;">
						<div style="text-align:center;"><h2>Phone Script</h2></div>
						<div>
							<div><span><b>Your Representative:</b> </span><span>Marcum Turnbull</span></div>
							<div><span><b>Office phone:</b> </span><span>324165451</span></div>
						</div>
						<div style="text-align: justify;">
							<div style="margin: 15px 0;">Based on your selected reason for supporting cannabis reform, we’ve included a handy phone
script you can use when calling representative:</div>
							<div>'.$chk_phnscript.'</div>
						</div>
					</div>
				</div>';
			
			$mpdf = new \Mpdf\Mpdf();
			$mpdf->WriteHTML($html);

			//save the file put which location you need folder/filname
			$mpdf->Output("joinorjudge.pdf", 'F');


			//out put in browser below output function
			$mpdf->Output();
			
	} catch(\Mpdf\MpdfException $e) {
		echo $e->getMessage();
	}
}
//add_action( 'init', 'joj_send_letter' );