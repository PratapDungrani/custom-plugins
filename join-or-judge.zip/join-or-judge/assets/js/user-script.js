jQuery(document).ready(function(){
	jQuery(".submit-info").on("click", function(e){
		var fname = jQuery(".isfname").val();
		var lname = jQuery(".islname").val();
		var isemail = jQuery(".isemail").val();
		var isadd = jQuery(".isaddress").val();
		
		if( fname == '' || lname == '' || isemail == '' || isadd == '') {
			jQuery(".info-error").show();
		} else {
			if(IsEmail(isemail) == false){
				jQuery(".email-error").show();
				jQuery(".info-error").hide();
			} else {
				var email = jQuery(".isemail").val();
				var address = jQuery(".isaddress").val();

				jQuery.ajax({
				type: 'POST',
				url: my_ajaxurl.ajax_url,
				data: {
					action: 'joj_validate_email',
					email: email,
					address: address
				},
				beforeSend: function(){
					jQuery(".submit-info").text("Finding...");
				},
				success: function(response){
					
					if(response != "true"){
						var result = JSON.parse(response);
						var can_name = result.can_name;
						var can_party = result.can_party;
						var can_photo = result.can_photo;
						var can_district = result.can_district;
						var can_phone = result.can_phone;
												
						if(can_name == null) {
							jQuery(".not-address").show();
						} else {
							jQuery(".is-repname").text(can_name);
							jQuery(".is-party").text(can_party);
							jQuery(".is-state").text(can_district);
							if(can_photo != null) {
								jQuery(".is-rep-img img").attr("src", can_photo);
							}
							
							jQuery(".info-error").hide();
							jQuery(".email-error").hide();
							jQuery(".email-exist").hide();
							jQuery(".not-address").hide();
							jQuery(".is-form").hide();
							jQuery(".is-letter").fadeIn(800);
						}
					} else {
						jQuery(".email-exist").show();
					}
				},
				complete:function(data){
					jQuery(".submit-info").text("FIND MY REPRESENTATIVE");
				},
				error: function(response){
					console.log(response);
				},
			});
			
				
			}
		}
		
		function IsEmail(isemail) {
			var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			if(!regex.test(isemail)) {
			   return false;
			}else{
			   return true;
			}
		}
	});
	
	
	
	jQuery(".submit-letter").on("click", function(){
		var reason_id = jQuery("input[name='reason']:checked").val();
		if( reason_id == undefined || reason_id == '') {
			jQuery(".reason-error").show();
		} else {
					
			var fname = jQuery(".isfname").val();
			var lname = jQuery(".islname").val();
			var email = jQuery(".isemail").val();
			var address = jQuery(".isaddress").val();
			var can_name = jQuery(".is-repname").text();

			jQuery.ajax({
				type: 'POST',
				url: my_ajaxurl.ajax_url,
				data: {
					action: 'joj_insert_data',
					fname: fname,
					lname: lname,
					email: email,
					address: address,
					can_name: can_name,
					reason_id: reason_id
				},
				beforeSend: function(){
					jQuery(".submit-letter").text("Sending letter...");
				},
				success: function(response){
					console.log(response);
					if(response == 1) {
						jQuery(".database-error").hide();
						jQuery(".reason-error").hide();
						jQuery(".is-letter").hide();
						jQuery(".is-message").fadeIn(800);
					} else {
						jQuery(".database-error").show();
					}
				},
				complete:function(data){
					jQuery(".submit-letter").text("WRITE MY LETTER");
				},
				error: function(response){
					console.log(response);
				},
			});			
		}
	});
})