<?php
/**
 * Plugin Name: Join Or Judge
 * Plugin URI: 
 * Description: Join Or Judge
 * Version: 1.0
 * Author: Pratap
 * Author URI: 
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Text Domain: join-or-judge
 * Domain Path: /languages/
 */
/*
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
    exit;
}

/*
 * Define variables
 */
global $wpdb;
define('JOJ_FILE', __FILE__);
define('JOJ_DIR', plugin_dir_path(JOJ_FILE));
define('JOJ_URL', plugins_url('/', JOJ_FILE));
define('JOJ_TEXTDOMAIN', 'join-or-judge');
define('JOJ_LETTER_TBL', $wpdb->prefix . "joj_letter" );

/**
 * Main Plugin JOJ class.
 */
class JOJ_Class {

    /**
     * JOJ constructor.
     */
    public function __construct() {
        $this->joj_hooks();
        $this->joj_include_files();
    }

    /**
     * Initialize hooks
     */
    public function joj_hooks() {
		add_action('activate_plugin', array($this, 'joj_create_table'));
		add_action('admin_menu', array($this, 'joj_menu'));
        add_action('plugins_loaded', array($this, 'joj_load_language_files'));
        add_action('admin_enqueue_scripts', array($this, 'joj_admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'joj_user_scripts'));
    }

    /**
     * Include required files
     */
    public function joj_include_files() {
        include_once( JOJ_DIR . 'includes/joj-shortcode.php' );
        include_once( JOJ_DIR . 'includes/joj-settings.php' );
        include_once( JOJ_DIR . 'includes/joj-options.php' );
        include_once( JOJ_DIR . 'includes/joj-csv-export.php' );
    }

    /**
     * Loads plugin textdomain
     */
    public function joj_load_language_files() {
        load_plugin_textdomain(JOJ_TEXTDOMAIN, false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /**
     *
     * Enqueue admin panel required css/js
     */
    public function joj_admin_scripts() {

        wp_register_style('joj-admin-style', JOJ_URL . 'assets/css/admin-style.css');
		wp_enqueue_style('joj-admin-style');

        wp_register_script('joj-admin-script', JOJ_URL . 'assets/js/admin-script.js', array('jquery'), false, true);
        wp_enqueue_script('joj-admin-script');
		
    }

	/**
     *
     * Enqueue user panel required css/js
     */
    public function joj_user_scripts() {

        wp_register_style('joj-user-style', JOJ_URL . 'assets/css/user-style.css');
		wp_enqueue_style('joj-user-style');

		wp_register_script('joj-user-script', JOJ_URL . 'assets/js/user-script.js', array('jquery'), false, true);
        wp_enqueue_script('joj-user-script');
		//wp_localize_script('joj-user-script', 'js_obj', array('joj_url' => JOJ_URL, ));
				
		wp_localize_script( 'joj-user-script', 'my_ajaxurl', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }

	/**
     *
     * Create admin side pages
     */
	public function joj_menu() {
        add_menu_page( __('Join or Judge', JOJ_TEXTDOMAIN), __('Join or Judge', JOJ_TEXTDOMAIN), 'manage_options', 'joj_letter', 'joj_letter',  JOJ_URL.'/assets/images/wsn-icon1.png' );
		add_submenu_page( 'joj_letter', __('Letters', JOJ_TEXTDOMAIN), __('Letters', JOJ_TEXTDOMAIN), 'manage_options', 'joj_letter', 'joj_letter' );
        add_submenu_page( 'joj_letter', __('Settings', JOJ_TEXTDOMAIN), __('Settings', JOJ_TEXTDOMAIN), 'manage_options', 'joj_settings', 'joj_settings' );
    }

	/**
     *
     * Create required table
     */
    public function joj_create_table() {

		global $wpdb;
        if ( $wpdb->get_var('SHOW TABLES LIKE " . JOJ_LETTER_TBL . "') != JOJ_LETTER_TBL ) {
            $sql = "CREATE TABLE " . JOJ_LETTER_TBL . " (
				id int(11) NOT NULL AUTO_INCREMENT,
				fname varchar(255) NOT NULL,
				lname varchar(255) NOT NULL,
				email varchar(255) NOT NULL,
				address varchar(255) NOT NULL,
				congressman varchar(255) NOT NULL,
				reason varchar(255) NOT NULL,
				created_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			    PRIMARY KEY (id))";
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
	    }

    }

	/**
     *
     * Create required page
     */
	function wsn_create_page() {

	  global $wpdb;

	  if ( null === $wpdb->get_row( "SELECT post_name FROM ". $wpdb->prefix ." posts WHERE post_name = 'new-page'", 'ARRAY_A' ) )
	  {

		$current_user = wp_get_current_user();

		// create post object
		$page = array(
		  'post_title'   => __( 'New Page', JOJ_TEXTDOMAIN ),
		  'post_content' => __( '[joinorjudge-letter-form]' ),
		  'post_status'  => 'publish',
		  'post_author'  => $current_user->ID,
		  'post_type'    => 'page',
		);

		// insert the post into the database
		wp_insert_post( $page );
	  }

	}

}

/*
* Starts our plugin class, easy!
*/
new JOJ_Class();