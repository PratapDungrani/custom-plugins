Direction to use Join or Judge plugin

1)	Install and Activate plugin
2)	Click “Join or Judge” Menu
	a.	Click “Options” menu to create reasons
		i.	Title => Reason name
		ii.	Description => Description supporting the reason for pdf letter
		iii.	Phone Script => Reason dependent script for user to call representative
	b.	Click “Letters” menu to view {user data} and to export data click “Export to CSV” button.
	c.	Click “Settings” menu to set default settings
		i.	Select image => For Thank you form
		ii.	Success message => For text on Thank you form below Image
		iii.	Mailing Instruction => Instructions text to appear on phone script pdf.
3)	Create page from “Pages ” menu
	a.	Give appropriate title
	b.	Place [joinorjudge-letter-form] in description/content section and save page.
	c.	Visit the page to view the form.
	
On Successful submission of the form, it will create 2 pdf and will send these pdf to user on their given email address. One for letter and second for phone script.