<?php
/* calculate shipping cost by Pratap */
add_filter( 'wcsdm_calculate_shipping_cost', 'calculate_shipping_cost', 10, 4 );				
function calculate_shipping_cost( $result, $api_response, $package, $obj ) {
	//get total item in cart
	$total_item = WC()->cart->get_cart_contents_count();
	
	//get delivery distance
	$distance = $api_response['distance'];
	
	//get shipping charge setting details
	$obj = json_decode(json_encode($obj), true);
	
	if(!empty($obj)) {
		
		$mincost; $rate_per_mile;
		
		$obj = $obj['instance_settings'];
		if(!empty($obj)) {
			
			//get minimum shipping charge
			$mincost = floatval($obj['min_cost']);
			
			//get rate per mile shipping charge details
			$table_rates = $obj['table_rates'];
			if(!empty($table_rates)) {
				
				if(!empty($table_rates[0])) {
					
					$rate_per_mile = floatval($table_rates[0]['rate_class_0']);
					
				}				
			}
		}
		
		if($distance > 0) {
			
			if($distance > 15) {
				
				$new_dis = $distance - 15;
				
				if($rate_per_mile > 0) {
					//if rate per mile shipping charge is provided
					$result['cost'] = (($new_dis * $rate_per_mile) + $mincost) * $total_item;
					
				} else {
					//default shipping charge
					$result['cost'] = $mincost * $total_item;
					
				}
				
			} else {
				
				if($mincost > 0) {
					
					$result['cost'] = $mincost * $total_item;
					
				}
				
			}
		}
	}
	return $result;
}

//special night delivery charges filter
/* plugin->order-delivery-date-for-woocommerce->includes->class-orddd-lite-process.php
 * add below code before: if ( $time_slot_fees_to_add > 0 && '' !== $time_slot_fees_to_add ) {
 * $time_slot_fees_to_add = apply_filters( 'orddd_modify_time_slot_charges', $time_slot_fees_to_add );
 *
 * plugin->order-delivery-date-for-woocommerce->js->orddd-lite-initialize-datepicker.js
 * addd below code before: jQuery( document ).on( "change", "#orddd_lite_time_slot", function() {
 * if ( jQuery("#orddd_lite_time_slot").val() != '' ) {
 *		jQuery("#orddd_lite_time_slot").change();
 * }
 */
add_filter( 'orddd_modify_time_slot_charges', 'special_shipping_charge', 10, 1);
function special_shipping_charge($time_slot_fees_to_add ) {
	
	global $woocommerce;
	//get total item in cart
	$cart_count = WC()->cart->get_cart_contents_count();
	
	if ( isset( $woocommerce->cart ) && ! empty( $woocommerce->cart ) ) {
		$cart_count = $woocommerce->cart->cart_contents_count;
	}
	
	if ( $cart_count > 1 ) {
		$time_slot_fees_to_add = $time_slot_fees_to_add * $cart_count;
	}
	return $time_slot_fees_to_add;
}
?>