<?php

/** 
 * Reorder Woo products by date ascending 
 */
//add_filter('woocommerce_default_catalog_orderby', 'rrc_default_catalog_orderby');

function rrc_default_catalog_orderby( $sort_by ) {
	return 'date asc';
}


/* Filters to change product order by Pratap */
add_filter( 'woocommerce_get_catalog_ordering_args', 'custom_woocommerce_get_catalog_ordering_args' );
add_filter( 'woocommerce_default_catalog_orderby_options', 'custom_woocommerce_catalog_orderby' );
add_filter( 'woocommerce_catalog_orderby', 'custom_woocommerce_catalog_orderby' );
 
 // Apply custom args to main query
function custom_woocommerce_get_catalog_ordering_args( $args ) {

	$orderby_value = isset( $_GET['orderby'] ) ? woocommerce_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
 
	
	//if ( 'date asc' == $orderby_value ) {
		$args['orderby'] = 'date';
		$args['order'] = 'ASC';
	//}
 
	return $args;
}
 
// Create new sorting method
function custom_woocommerce_catalog_orderby( $sortby ) {
	
	$sortby['oldest_to_recent'] = __( 'Oldest to most recent', 'woocommerce' );
	
	return $sortby;
}
?>

<style>
@media (max-width: 568px) {
	.wc-block-grid .wc-block-grid__products .wc-block-grid__product
	 {
	    margin: 0;
	    max-width: 50%;
	    padding: 0;
	    flex: 1 0 50%;
	    display: inline-block;
		vertical-align: text-top;
	}
}

@media (max-width: 480px) {
	.wc-block-grid .wc-block-grid__products .wc-block-grid__product
	 {
	    margin: 0;
	    max-width: 50%;
	    padding: 0;
	    flex: 1 0 50%;
	    display: inline-block;
		vertical-align: text-top;
	}
}
</style>