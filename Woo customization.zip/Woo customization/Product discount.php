<?php
/*Product discount based on category and quantity by Pratap*/
function checkout_update_function($data) {
	
	parse_str($data, $data);
	
	//get pickup date
	$date = $data['pi_delivery_date'];
	
	$months = array(
		"januari"   => "January",
		"februari"  => "February",
		"maart"     => "March",
		"april"     => "April",
		"mei"       => "May",
		"juni"      => "June",
		"juli"      => "July",
		"augustus"  => "August",
		"september" => "September",
		"oktober"   => "October",
		"november"  => "November",
		"december"  => "December"
	);
	
	//convert date to english if date is in dutch
	if($date) {
		$ddate = explode(" ", $date);
		$dmonth = $ddate[1];
		$emonth = $months[$dmonth];
		if($emonth) {
			$ddate[1] = $emonth;
			$date = implode(" ", $ddate);
		}
	}
	
	//get day from date
	$timestamp = strtotime($date);
	$dday = date('D', $timestamp);
	$offer_day = 'Monday';
	
	//remove coupon discount if applied
	WC()->cart->remove_coupon( 'discount_free' );
	
	//check if pickup day is Monday
	if (strpos($offer_day, $dday) !== false) {
		//get cart object
		$cart = WC()->cart->get_cart();
		
		$is_cat = $free_cat = array(); $is_cat_count; $free_cat_count; $ttl_free_prd;
		foreach ( $cart as $cart_item_key => $cart_item ) {
			
			if ( has_term( 'Groot brood', 'product_cat', $cart_item['product_id'] ) ) { //if product has large bread category
				$is_cat[] = $cart_item['product_id'];
				$is_cat_count  = $is_cat_count + $cart_item['quantity']; //get quantity
			} else if (has_term( 'Klein brood', 'product_cat', $cart_item['product_id'] ) ) { //if product has small bread category
				$free_cat[] = $cart_item['product_id'];
				$free_cat_count = $free_cat_count + $cart_item['quantity']; //get quantity
			}
			
		}
			
		if($is_cat_count >= 3 && $is_cat_count != 4) {					
			//calculate total number of free product
			if ($is_cat_count % 3 == 0) {
				$ttl_free_prd = $is_cat_count / 3;
			} else {
				$ttl_free_prd = intdiv($is_cat_count, 3);
			}			
			
			//show notice
			wc_add_notice( __( 'You are eligible for '. $ttl_free_prd .' free small Bread!', 'woocommerce' ), 'success' );
			
		} else if($is_cat_count == 4){
			//show notice
			wc_add_notice( __( 'Congratulations!! You have received €1.75 discount.', 'woocommerce' ), 'success' );
			
			//auto apply coupon
			WC()->cart->apply_coupon( 'discount_free' );
		}
		
		//check if free product in cart
		if($free_cat_count > 0 && $ttl_free_prd > 0) {
			
			foreach (  $cart as $key => $value ) {
				
				if($ttl_free_prd > 0) {			
				
					if (in_array($value['product_id'], $free_cat)) {
						$price = (float)$value['data']->get_price();
						$qty = $value['quantity'];
						
						if($qty <= $ttl_free_prd) {
							$value['data']->set_price(0.0); // set the new price
							$ttl_free_prd = $ttl_free_prd - $qty;
						} else {
							$dprice = ($qty*$price) - ($ttl_free_prd*$price);
							$dprice = $dprice/$qty;
							$value['data']->set_price($dprice);						
							$ttl_free_prd = 0;
						}
					}
				}
			}
		}
	}
}
add_action('woocommerce_checkout_update_order_review', 'checkout_update_function', 10, 1);

//change label of auto coupon
add_filter( 'woocommerce_cart_totals_coupon_label', 'change_coupon_label', 10, 2  );
function change_coupon_label( $coupon_html, $coupon ) {
	$code = $coupon->get_code();
	if($code == 'discount_free') {  //if 'discount_free' code is applied
		$coupon_html = 'Discount'; 
		return $coupon_html;
	}
	return $coupon_html;
}

//hide remove button for auto coupon
add_filter( 'woocommerce_cart_totals_coupon_html', 'woocommerce_cart_totals_coupon_html_callback', 10, 3  );
function woocommerce_cart_totals_coupon_html_callback( $coupon_html, $coupon, $discount_amount_html ) { 
    $code = $coupon->get_code();
	if($code == 'discount_free') {  //if 'discount_free' code is applied
		return $discount_amount_html;
	}
	return $coupon_html;
}

//remove auto coupon on cart page
add_action( 'woocommerce_before_calculate_totals', 'auto_add_remove_coupon' );
function auto_add_remove_coupon( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
        return;
	
	 if ( is_page( 'cart' ) || is_cart() ) {
		 $coupon_code = 'discount_free';

		 if ( $cart->has_discount( $coupon_code ) ) {
			 $cart->remove_coupon( $coupon_code );
			 wc_clear_notices();
		 } 
	 }
}

//hide coupon success msg if auto coupon applied
add_filter( 'woocommerce_coupon_message', 'filter_woocommerce_coupon_message', 10, 3 );
function filter_woocommerce_coupon_message( $msg, $msg_code, $coupon ) {
    $code = $coupon->get_code();
	if($code == 'discount_free') {  //if 'discount_free' code is applied
		$msg = '';
		return $msg;
	}
    return $msg;
}

add_action( 'wp_footer', function () { ?>
<script>
	jQuery('#pi_delivery_date').on('change', function(){
		jQuery( "body" ).trigger( "update_checkout" );
	});
</script>
<?php
});

