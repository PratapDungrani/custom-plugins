<?php
/* Add duty to price and calculate tax on single product page by Pratap */
add_filter( 'woocommerce_get_price_html', 'filter_wc_variable_price_html', 99, 2 );
function filter_wc_variable_price_html( $price_html, $product ) {
	//get product categoies
	$categories = wc_get_product_category_list($product->get_id());
	$cat_exist = 'false';
	
	if($categories != '') {  //if product has category
		$categories = strip_tags($categories);  //remove html from string
		
		if( strpos($categories, ',') !== false ) {  //if multiple categories assigned
			$categories_ar = explode(', ', $categories);  //create category array
			
			if (in_array('WINE', $categories_ar)) {  //check if category WINE exist in array
				$cat_exist = 'true';
			}
		} elseif ('WINE' == $categories) {  //check if category is WINE
			$cat_exist = 'true';
		}
	}
	
	//if not selected category or country is not UK
    if( $cat_exist == 'false' || get_woocommerce_currency() != 'GBP') {
       
		return $price_html;  //return default price html
		
	} elseif( $cat_exist == 'true' ) {  //if selected category exist
		
		$before_duty_price = $product->price;  //default price
		$duty = (91.68*1*1)/100;  //calculate duty
		$after_duty_price = $before_duty_price + $duty;  //price with duty
		$price = $after_duty_price;
		
		$tax_rates = WC_Tax::get_rates( $product->get_tax_class() );  //get saved tax rate
		$taxes     = WC_Tax::calc_tax( $price, $tax_rates, false );  //calculate tax
		
		//return new price html
		return sprintf(
			__( '%s %s', 'woocommerce' ),
			wc_price( $price ),
			'<small class="woocommerce-price-suffix">' . __( 'incl VAT', 'woocommerce' ) . wc_price( $price + array_sum( $taxes ) ). '</small>'
		);
	}
}